import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  // Sheets
  const sheets = [
    { id: 'sheet-a101', name: 'A-101 Ground Floor Plan', category: 'Floor Plans', scale: '1/4" = 1\'', pageIndex: 0, sortOrder: 0 },
    { id: 'sheet-a102', name: 'A-102 Second Floor Plan', category: 'Floor Plans', scale: '1/4" = 1\'', pageIndex: 1, sortOrder: 1 },
    { id: 'sheet-a201', name: 'A-201 North Elevation', category: 'Elevations', scale: '1/4" = 1\'', pageIndex: 2, sortOrder: 2 },
    { id: 'sheet-a202', name: 'A-202 South Elevation', category: 'Elevations', scale: '1/4" = 1\'', pageIndex: 3, sortOrder: 3 },
    { id: 'sheet-s101', name: 'S-101 Foundation Plan', category: 'Structural', scale: '1/4" = 1\'', pageIndex: 4, sortOrder: 4 },
    { id: 'sheet-m101', name: 'M-101 Mechanical Plan', category: 'Mechanical', scale: '1/8" = 1\'', pageIndex: 5, sortOrder: 5 },
  ];
  for (const s of sheets) {
    await prisma.sheet.upsert({ where: { id: s.id }, update: s, create: s });
  }

  // Key Measures (construction codes) - grouped by realistic categories
  const keyMeasures = [
    // CONCRETE
    { id: 'km-concrete', name: 'SOG_4000', color: '#64748B', category: 'CONCRETE', sortOrder: 0 },
    { id: 'km-rebar', name: 'RB_4_GR60', color: '#DC2626', category: 'CONCRETE', sortOrder: 1 },
    // LVL
    { id: 'km-joist', name: 'LVL_1178', color: '#92400E', category: 'LVL', sortOrder: 2 },
    { id: 'km-header', name: 'HDR_2x10', color: '#B45309', category: 'LVL', sortOrder: 3 },
    // RIM BOARD
    { id: 'km-rimboard1', name: 'RIM_2x10', color: '#A16207', category: 'RIM BOARD', sortOrder: 4 },
    // ROOFING
    { id: 'km-roofing', name: 'RF_SHGL_30', color: '#7C3AED', category: 'ROOFING', sortOrder: 5 },
    { id: 'km-gutter', name: 'GT_ALU_5IN', color: '#6D28D9', category: 'ROOFING', sortOrder: 6 },
    // SHEATHING
    { id: 'km-sheath1', name: 'SHTH_OSB_7/16', color: '#D97706', category: 'SHEATHING', sortOrder: 7 },
    { id: 'km-sheath2', name: 'SHTH_PLY_3/4', color: '#CA8A04', category: 'SHEATHING', sortOrder: 8 },
    // SIDING
    { id: 'km-siding1', name: 'SID_VNL_D4', color: '#0891B2', category: 'SIDING', sortOrder: 9 },
    // SILL PLATE
    { id: 'km-sill1', name: 'SILL_2x6_PT', color: '#059669', category: 'SILL PLATE', sortOrder: 10 },
    // WALLS EXTERIOR
    { id: 'km-framing', name: 'WALL_EXT_2x4_10', color: '#0EA5E9', category: 'WALLS EXTERIOR', sortOrder: 11 },
    { id: 'km-wallext2', name: 'WALL_EXT_2x4_12', color: '#0284C7', category: 'WALLS EXTERIOR', sortOrder: 12 },
    { id: 'km-wallext3', name: 'WALL_EXT_2x6_10', color: '#0369A1', category: 'WALLS EXTERIOR', sortOrder: 13 },
    // WALLS INTERIOR
    { id: 'km-drywall', name: 'DW_5/8_FRC', color: '#78716C', category: 'WALLS INTERIOR', sortOrder: 14 },
    { id: 'km-paint', name: 'PT_INT_LTX', color: '#A3A3A3', category: 'WALLS INTERIOR', sortOrder: 15 },
    // FINISHES
    { id: 'km-flooring', name: 'VCT_12x12', color: '#10B981', category: 'FINISHES', sortOrder: 16 },
    { id: 'km-ceiling', name: 'ACT_2x4', color: '#8B5CF6', category: 'FINISHES', sortOrder: 17 },
    { id: 'km-carpet', name: 'FLR_CPT_28', color: '#EC4899', category: 'FINISHES', sortOrder: 18 },
    { id: 'km-deckboard', name: 'Deckboard', color: '#F59E0B', category: 'FINISHES', sortOrder: 19 },
    // OPENINGS
    { id: 'km-window', name: 'WN_DH_36x60', color: '#2563EB', category: 'OPENINGS', sortOrder: 20 },
    { id: 'km-ext-door', name: 'DR_EXT_36', color: '#3B82F6', category: 'OPENINGS', sortOrder: 21 },
    { id: 'km-int-door', name: 'DR_INT_32', color: '#60A5FA', category: 'OPENINGS', sortOrder: 22 },
    // INSULATION
    { id: 'km-insul-batt', name: 'INS_R19_BATT', color: '#F97316', category: 'INSULATION', sortOrder: 23 },
    // ELECTRICAL
    { id: 'km-electrical', name: 'EL_DPX_20A', color: '#FBBF24', category: 'ELECTRICAL', sortOrder: 24 },
    // PLUMBING
    { id: 'km-plumbing', name: 'PLB_FIX_GRP', color: '#06B6D4', category: 'PLUMBING', sortOrder: 25 },
    // MECHANICAL
    { id: 'km-hvac-duct', name: 'HVAC_DT_12R', color: '#14B8A6', category: 'MECHANICAL', sortOrder: 26 },
    // FIRE PROTECTION
    { id: 'km-sprinkler', name: 'FP_SPK_PND', color: '#EF4444', category: 'FIRE PROTECTION', sortOrder: 27 },
    // HARDWARE
    { id: 'km-hinge', name: 'HW_DS_Hinge', color: '#71717A', category: 'HARDWARE', sortOrder: 28 },
  ];
  for (const km of keyMeasures) {
    await prisma.keyMeasure.upsert({ where: { id: km.id }, update: km, create: km });
  }

  // Sections
  const sections = [
    { id: 'sec-wing-a', name: 'Wing A - Administrative', sortOrder: 0 },
    { id: 'sec-wing-b', name: 'Wing B - Medical', sortOrder: 1 },
    { id: 'sec-common', name: 'Common Areas', sortOrder: 2 },
    { id: 'sec-exterior', name: 'Exterior', sortOrder: 3 },
  ];
  for (const sec of sections) {
    await prisma.section.upsert({ where: { id: sec.id }, update: sec, create: sec });
  }

  // Uses
  const uses = [
    { id: 'use-bid-estimate', name: 'Bid Estimate', sortOrder: 0 },
    { id: 'use-budget', name: 'Budget', sortOrder: 1 },
    { id: 'use-change-order', name: 'Change Order', sortOrder: 2 },
    { id: 'use-verification', name: 'Verification', sortOrder: 3 },
  ];
  for (const u of uses) {
    await prisma.use.upsert({ where: { id: u.id }, update: u, create: u });
  }

  // Measurements with markup data (canvas coordinates) - linked to sheets
  // Naming convention: ABBREV_FLOOR or FLOOR_TYPE_SIZE_SCHEDULE (construction takeoff codes)
  const measurements = [
    // AREA measurements
    {
      id: 'meas-lobby',
      name: 'RM_1F',
      type: 'area',
      color: '#3B82F6',
      value: 482.50,
      unit: 'SQ FT',
      segmentCount: 8,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 0,
      markupData: { type: 'polygon', points: [[120,180],[320,180],[320,340],[120,340]] },
    },
    {
      id: 'meas-corridor',
      name: 'SQ_1F',
      type: 'area',
      color: '#8B5CF6',
      value: 316.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 1,
      markupData: { type: 'polygon', points: [[320,220],[580,220],[580,280],[320,280]] },
    },
    {
      id: 'meas-office1',
      name: 'SOG_6000',
      type: 'area',
      color: '#10B981',
      value: 196.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 2,
      markupData: { type: 'polygon', points: [[380,100],[520,100],[520,210],[380,210]] },
    },
    {
      id: 'meas-office2',
      name: 'SOG_4000',
      type: 'area',
      color: '#F59E0B',
      value: 224.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 3,
      markupData: { type: 'polygon', points: [[380,290],[540,290],[540,420],[380,420]] },
    },
    {
      id: 'meas-conference',
      name: 'DR_EXT_36',
      type: 'area',
      color: '#EF4444',
      value: 360.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 4,
      markupData: { type: 'polygon', points: [[580,100],[740,100],[740,280],[580,280]] },
    },
    {
      id: 'meas-breakroom',
      name: 'INS_R19_BATT',
      type: 'area',
      color: '#06B6D4',
      value: 548.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 5,
      markupData: { type: 'polygon', points: [[580,290],[720,290],[720,410],[580,410]] },
    },
    {
      id: 'meas-restroom',
      name: 'RF_SHGL_30',
      type: 'area',
      color: '#EC4899',
      value: 1200.00,
      unit: 'SQ FT',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 6,
      markupData: { type: 'polygon', points: [[120,350],[240,350],[240,440],[120,440]] },
    },
    // LINEAR measurements
    {
      id: 'meas-wall-north',
      name: '1F_WI_2x4_8',
      type: 'linear',
      color: '#F97316',
      value: 64.50,
      unit: 'LF',
      segmentCount: 12,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 7,
      markupData: { type: 'line', points: [[120,180],[740,180]] },
    },
    {
      id: 'meas-wall-south',
      name: '1F_WE_2x6_8',
      type: 'linear',
      color: '#D946EF',
      value: 52.00,
      unit: 'LF',
      segmentCount: 14,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 8,
      markupData: { type: 'line', points: [[120,440],[720,440]] },
    },
    {
      id: 'meas-baseboard',
      name: '1F_WI_2x6_8',
      type: 'linear',
      color: '#84CC16',
      value: 186.00,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 9,
      markupData: { type: 'line', points: [[120,340],[320,340],[320,280],[580,280],[580,410],[720,410]] },
    },
    {
      id: 'meas-crown',
      name: 'North Partitio...',
      type: 'linear',
      color: '#14B8A6',
      value: 98.00,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 10,
      markupData: { type: 'line', points: [[380,100],[740,100]] },
    },
    {
      id: 'meas-south-part',
      name: 'South Partitio...',
      type: 'linear',
      color: '#0EA5E9',
      value: 52.00,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 11,
      markupData: { type: 'line', points: [[120,420],[720,420]] },
    },
    {
      id: 'meas-vinyl-base',
      name: 'Vinyl Base Tr...',
      type: 'linear',
      color: '#84CC16',
      value: 186.00,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 12,
      markupData: { type: 'line', points: [[140,340],[320,340],[320,300],[580,300]] },
    },
    {
      id: 'meas-crown-mold',
      name: 'Crown Molding',
      type: 'linear',
      color: '#14B8A6',
      value: 98.00,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 13,
      markupData: { type: 'line', points: [[390,110],[730,110]] },
    },
    // COUNT measurements
    {
      id: 'meas-outlets',
      name: 'EL_DPX_20A',
      type: 'count',
      color: '#F59E0B',
      value: 18,
      unit: 'EA',
      segmentCount: 18,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 14,
      markupData: { type: 'points', points: [[150,220],[280,220],[400,150],[480,150],[400,350],[500,350],[620,150],[700,150],[620,350],[680,350],[150,400],[220,400],[650,200],[700,250],[450,260],[550,260],[200,300],[260,260]] },
    },
    {
      id: 'meas-lights',
      name: 'DR_INT_32',
      type: 'count',
      color: '#6366F1',
      value: 8,
      unit: 'EA',
      segmentCount: 8,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 15,
      markupData: { type: 'points', points: [[200,260],[160,310],[280,310],[440,150],[480,180],[450,370],[500,370],[640,180]] },
    },
    {
      id: 'meas-sprinklers',
      name: 'RB_4_GR60',
      type: 'count',
      color: '#EF4444',
      value: 420,
      unit: 'LF',
      segmentCount: 1,
      visible: true,
      isAI: false,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 16,
      markupData: { type: 'points', points: [[200,240],[200,380],[440,160],[440,360],[640,160],[640,360],[300,250],[560,250]] },
    },
    {
      id: 'meas-switches',
      name: 'WD_SINGLE_J6',
      type: 'count',
      color: '#A855F7',
      value: 2,
      unit: 'EA',
      segmentCount: 2,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 17,
      markupData: { type: 'points', points: [[390,110],[590,110]] },
    },
    {
      id: 'meas-wd-single-dim',
      name: "WD_SINGLE_1'6\"x0'0\"_J6",
      type: 'count',
      color: '#0EA5E9',
      value: 2,
      unit: 'EA',
      segmentCount: 2,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 18,
      markupData: { type: 'points', points: [[200,190],[600,190]] },
    },
    {
      id: 'meas-wd-sliding-14',
      name: "WD_SLIDING_1'4\"x0'0\"_J4",
      type: 'count',
      color: '#D946EF',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 19,
      markupData: { type: 'points', points: [[450,300]] },
    },
    {
      id: 'meas-wd-sliding-16',
      name: "WD_SLIDING_1'6\"x0'0\"_J4",
      type: 'count',
      color: '#F97316',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 20,
      markupData: { type: 'points', points: [[650,300]] },
    },
    {
      id: 'meas-sliding-j6',
      name: 'SLIDING_J6',
      type: 'count',
      color: '#10B981',
      value: 3,
      unit: 'EA',
      segmentCount: 3,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 21,
      markupData: { type: 'points', points: [[300,380],[500,380],[700,380]] },
    },
    {
      id: 'meas-wd-sliding-12',
      name: "WD_SLIDING_1'2\"x0'0\"_J6",
      type: 'count',
      color: '#64748B',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 22,
      markupData: { type: 'points', points: [[350,250]] },
    },
    {
      id: 'meas-di-single-right',
      name: 'DI_SINGLE_RIGHT_J4',
      type: 'count',
      color: '#DC2626',
      value: 2,
      unit: 'EA',
      segmentCount: 2,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 23,
      markupData: { type: 'points', points: [[330,190],[590,300]] },
    },
    {
      id: 'meas-di-single-left-dim',
      name: "DI_SINGLE_LEFT_3'6\"x6'8\"_J4",
      type: 'count',
      color: '#7C3AED',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 24,
      markupData: { type: 'points', points: [[200,350]] },
    },
    {
      id: 'meas-di-single-left',
      name: 'DI_SINGLE_LEFT_J4',
      type: 'count',
      color: '#CA8A04',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 25,
      markupData: { type: 'points', points: [[700,200]] },
    },
    {
      id: 'meas-gd-j6',
      name: 'GD_J6',
      type: 'count',
      color: '#059669',
      value: 1,
      unit: 'EA',
      segmentCount: 1,
      visible: true,
      isAI: true,
      groupId: null,
      sheetId: 'sheet-a101',
      sortOrder: 26,
      markupData: { type: 'points', points: [[130,300]] },
    },
  ];

  for (const m of measurements) {
    await prisma.measurement.upsert({
      where: { id: m.id },
      update: { ...m },
      create: { ...m },
    });
  }

  // Key Measure line items — manually entered, NOT from Quick Measures
  // These are standalone measurements (isAI=false, segmentCount=1) with assignments
  const kmLineItems = [
    { id: 'km-meas-1', name: 'SOG_6000', type: 'area', color: '#64748B', value: 482.50, unit: 'SQ FT', sheetId: 'sheet-a101', sortOrder: 30, keyMeasureId: 'km-concrete', sectionId: 'sec-common',
      markupData: { type: 'polygon', points: [[125,185],[315,185],[315,335],[125,335]] } },
    { id: 'km-meas-2', name: 'DW_5/8_FRC', type: 'linear', color: '#78716C', value: 64.50, unit: 'LF', sheetId: 'sheet-a101', sortOrder: 31, keyMeasureId: 'km-drywall', sectionId: 'sec-wing-a',
      markupData: { type: 'line', points: [[125,185],[735,185]] } },
    { id: 'km-meas-3', name: 'VCT_12x12', type: 'area', color: '#0EA5E9', value: 316.00, unit: 'SQ FT', sheetId: 'sheet-a101', sortOrder: 32, keyMeasureId: 'km-flooring', sectionId: 'sec-common',
      markupData: { type: 'polygon', points: [[325,225],[575,225],[575,275],[325,275]] } },
    { id: 'km-meas-4', name: 'ACT_2x4', type: 'area', color: '#A3A3A3', value: 360.00, unit: 'SQ FT', sheetId: 'sheet-a101', sortOrder: 33, keyMeasureId: 'km-ceiling', sectionId: 'sec-common',
      markupData: { type: 'polygon', points: [[585,105],[735,105],[735,275],[585,275]] } },
    { id: 'km-meas-5', name: 'EL_DPX_20A', type: 'count', color: '#CA8A04', value: 18, unit: 'EA', sheetId: 'sheet-a101', sortOrder: 34, keyMeasureId: 'km-electrical', sectionId: 'sec-common',
      markupData: { type: 'points', points: [[155,225],[285,225],[405,155]] } },
    { id: 'km-meas-6', name: 'INS_R19_BATT', type: 'area', color: '#D97706', value: 548.00, unit: 'SQ FT', sheetId: 'sheet-a101', sortOrder: 35, keyMeasureId: 'km-insul-batt', sectionId: 'sec-exterior',
      markupData: { type: 'polygon', points: [[130,120],[730,120],[730,200],[130,200]] } },
    { id: 'km-meas-7', name: 'RF_SHGL_30', type: 'area', color: '#7C3AED', value: 1200.00, unit: 'SQ FT', sheetId: 'sheet-a101', sortOrder: 36, keyMeasureId: 'km-roofing', sectionId: 'sec-exterior',
      markupData: { type: 'polygon', points: [[130,220],[730,220],[730,380],[130,380]] } },
    { id: 'km-meas-8', name: 'DI_SINGLE_RIGHT_J4', type: 'count', color: '#059669', value: 8, unit: 'EA', sheetId: 'sheet-a101', sortOrder: 37, keyMeasureId: 'km-int-door', sectionId: 'sec-wing-a',
      markupData: { type: 'points', points: [[200,150],[350,150],[500,150],[200,350],[350,350],[500,350],[650,150],[650,350]] } },
    { id: 'km-meas-9', name: 'RB_4_GR60', type: 'linear', color: '#DC2626', value: 420.00, unit: 'LF', sheetId: 'sheet-a101', sortOrder: 38, keyMeasureId: 'km-rebar', sectionId: 'sec-common',
      markupData: { type: 'line', points: [[130,300],[730,300]] } },
    { id: 'km-meas-10', name: 'HVAC_SA_12x8', type: 'linear', color: '#2563EB', value: 185.00, unit: 'LF', sheetId: 'sheet-a101', sortOrder: 39, keyMeasureId: 'km-hvac-duct', sectionId: 'sec-common',
      markupData: { type: 'line', points: [[150,250],[400,250],[400,350],[700,350]] } },
  ];

  // Map km line items to use categories
  const kmUseMap: Record<string, string> = {
    'km-meas-1': 'use-bid-estimate',
    'km-meas-2': 'use-bid-estimate',
    'km-meas-3': 'use-budget',
    'km-meas-4': 'use-budget',
    'km-meas-5': 'use-bid-estimate',
    'km-meas-6': 'use-change-order',
    'km-meas-7': 'use-change-order',
    'km-meas-8': 'use-verification',
    'km-meas-9': 'use-bid-estimate',
    'km-meas-10': 'use-verification',
  };

  for (const item of kmLineItems) {
    const { keyMeasureId, sectionId, ...measData } = item;
    await prisma.measurement.upsert({
      where: { id: measData.id },
      update: { ...measData, segmentCount: 1, visible: true, isAI: false, groupId: null },
      create: { ...measData, segmentCount: 1, visible: true, isAI: false, groupId: null },
    });
    await prisma.assignment.upsert({
      where: { id: `assign-${measData.id}` },
      update: { measurementId: measData.id, keyMeasureId, sectionId, useId: kmUseMap[measData.id] || null },
      create: { id: `assign-${measData.id}`, measurementId: measData.id, keyMeasureId, sectionId, useId: kmUseMap[measData.id] || null },
    });
  }

  console.log('Seed completed successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });