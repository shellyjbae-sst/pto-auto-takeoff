export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const keyMeasures = await prisma.keyMeasure.findMany({ orderBy: { sortOrder: 'asc' } });
    return NextResponse.json(keyMeasures);
  } catch (error: any) {
    console.error('GET key measures error:', error);
    return NextResponse.json({ error: 'Failed to fetch key measures' }, { status: 500 });
  }
}
