'use client';

import React, { useState, useMemo, useCallback } from 'react';
import { KeyMeasureData, MeasurementData, AssignmentData } from '@/types/takeoff';
import {
  ChevronDown,
  ChevronRight,
  Search,
  Filter,
  MoreHorizontal,
  EyeOff,
  Square,
  Minus,
  Circle,
  Sparkles,
  Pencil,
  Trash2,
  GitCompareArrows,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

type FilterType = 'all' | 'area' | 'linear' | 'count';

interface RightPanelProps {
  keyMeasures: KeyMeasureData[];
  activeKeyMeasureId: string | null;
  onSelectKeyMeasure: (id: string | null) => void;
  measurements: MeasurementData[];
  assignments: AssignmentData[];
  hoveredId: string | null;
  selectedIds: Set<string>;
  onHover: (id: string | null) => void;
  onToggleVisibility: (id: string) => void;
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onAssign: (ids: string[], anchorRect?: DOMRect) => void;
  onDelete: (ids: string[]) => void;
  onDuplicate: (id: string) => void;
  onRename: (id: string, name: string) => void;
  onNewClick: () => void;
}

export default function RightPanel({
  keyMeasures,
  activeKeyMeasureId,
  onSelectKeyMeasure,
  measurements,
  assignments,
  hoveredId,
  selectedIds,
  onHover,
  onToggleVisibility,
  onToggleSelect,
  onSelectAll,
  onDeselectAll,
  onAssign,
  onDelete,
  onDuplicate,
  onRename,
  onNewClick,
}: RightPanelProps) {
  return (
    <div className="w-[320px] min-w-[320px] bg-white border-l border-gray-200 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
        <h3 className="text-sm font-semibold text-gray-800 flex-1">Takeoff Sections</h3>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
              <MoreHorizontal className="w-4 h-4 text-gray-500" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem className="text-xs cursor-pointer">Expand All</DropdownMenuItem>
            <DropdownMenuItem className="text-xs cursor-pointer">Collapse All</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-xs cursor-pointer">Sort by Name</DropdownMenuItem>
            <DropdownMenuItem className="text-xs cursor-pointer">Sort by Category</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Tabs using shadcn */}
      <Tabs defaultValue="km" className="flex flex-col flex-1 overflow-hidden">
        <TabsList className="w-full rounded-none border-b border-gray-200 bg-white h-auto p-0 justify-stretch">
          <TabsTrigger
            value="km"
            className="flex-1 rounded-none border-b-2 border-transparent py-2 text-xs font-medium data-[state=active]:border-blue-600 data-[state=active]:text-blue-700 data-[state=active]:shadow-none data-[state=active]:bg-white text-gray-500 hover:text-gray-700"
          >
            Key Measures
          </TabsTrigger>
          <TabsTrigger
            value="qm"
            className="flex-1 rounded-none border-b-2 border-transparent py-2 text-xs font-medium data-[state=active]:border-blue-600 data-[state=active]:text-blue-700 data-[state=active]:shadow-none data-[state=active]:bg-white text-gray-500 hover:text-gray-700"
          >
            Quick Measures
          </TabsTrigger>
        </TabsList>

        <TabsContent value="km" className="flex-1 flex flex-col overflow-hidden mt-0 data-[state=inactive]:hidden">
          <KMTab
            keyMeasures={keyMeasures}
            activeKeyMeasureId={activeKeyMeasureId}
            onSelectKeyMeasure={onSelectKeyMeasure}
          />
        </TabsContent>

        <TabsContent value="qm" className="flex-1 flex flex-col overflow-hidden mt-0 data-[state=inactive]:hidden">
          <QMTab
            measurements={measurements}
            assignments={assignments}
            hoveredId={hoveredId}
            selectedIds={selectedIds}
            onHover={onHover}
            onToggleVisibility={onToggleVisibility}
            onToggleSelect={onToggleSelect}
            onSelectAll={onSelectAll}
            onDeselectAll={onDeselectAll}
            onAssign={onAssign}
            onDelete={onDelete}
            onDuplicate={onDuplicate}
            onRename={onRename}
            onNewClick={onNewClick}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ============== KM Tab ============== */
function KMTab({
  keyMeasures,
  activeKeyMeasureId,
  onSelectKeyMeasure,
}: {
  keyMeasures: KeyMeasureData[];
  activeKeyMeasureId: string | null;
  onSelectKeyMeasure: (id: string | null) => void;
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [collapsedCategories, setCollapsedCategories] = useState<Set<string>>(new Set());

  const grouped = useMemo(() => {
    const filtered = (keyMeasures ?? []).filter((km) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return km.name.toLowerCase().includes(q) || km.category.toLowerCase().includes(q);
    });
    const groups: Record<string, KeyMeasureData[]> = {};
    filtered.forEach((km) => {
      const cat = km.category || 'GENERAL';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(km);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [keyMeasures, searchQuery]);

  const toggleCategory = (cat: string) => {
    setCollapsedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Search */}
      <div className="px-3 py-2 border-b border-gray-100">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
          <Input
            type="text"
            placeholder="Search ..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 pl-8 text-xs"
          />
        </div>
      </div>

      {/* Category Accordion */}
      <div className="flex-1 overflow-y-auto">
        {grouped.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <p className="text-xs text-gray-400">No key measures found.</p>
          </div>
        ) : (
          grouped.map(([category, items]) => {
            const isCollapsed = collapsedCategories.has(category);
            return (
              <div key={category} className="border-b border-gray-100">
                <button
                  onClick={() => toggleCategory(category)}
                  className="w-full flex items-center gap-1.5 px-3 py-2 text-xs hover:bg-gray-50 transition-colors"
                >
                  {isCollapsed ? (
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  )}
                  <span className="font-semibold text-gray-600 uppercase tracking-wider text-[11px]">{category}</span>
                  <span className="ml-auto text-[10px] text-gray-400 font-mono">{items.length}</span>
                </button>
                {!isCollapsed && (
                  <div className="pb-0.5">
                    {items.map((km) => {
                      const isActive = activeKeyMeasureId === km.id;
                      return (
                        <button
                          key={km.id}
                          onClick={() => onSelectKeyMeasure(isActive ? null : km.id)}
                          className={`w-full flex items-center gap-2 pl-8 pr-3 py-1.5 text-xs transition-colors ${
                            isActive ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          <div
                            className="w-3 h-3 rounded-sm flex-shrink-0 border border-black/10"
                            style={{ backgroundColor: km.color }}
                          />
                          <span className="truncate font-mono text-[11px]">{km.name}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

/* ============== QM Tab ============== */
function QMTab({
  measurements,
  assignments,
  hoveredId,
  selectedIds,
  onHover,
  onToggleVisibility,
  onToggleSelect,
  onSelectAll,
  onDeselectAll,
  onAssign,
  onDelete,
  onDuplicate,
  onRename,
  onNewClick,
}: {
  measurements: MeasurementData[];
  assignments: AssignmentData[];
  hoveredId: string | null;
  selectedIds: Set<string>;
  onHover: (id: string | null) => void;
  onToggleVisibility: (id: string) => void;
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onAssign: (ids: string[], anchorRect?: DOMRect) => void;
  onDelete: (ids: string[]) => void;
  onDuplicate: (id: string) => void;
  onRename: (id: string, name: string) => void;
  onNewClick: () => void;
}) {
  const [filter, setFilter] = useState<FilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeAssignIconId, setActiveAssignIconId] = useState<string | null>(null);
  const [inspectedQMId, setInspectedQMId] = useState<string | null>(null);

  const safeSelectedIds = selectedIds ?? new Set<string>();

  /* Build map: measurementId → list of assigned KM names */
  const assignedKMMap: Record<string, { assignmentId: string; kmName: string }[]> = {};
  (assignments ?? []).forEach((a: AssignmentData) => {
    const mId = a?.measurementId ?? '';
    if (!assignedKMMap[mId]) assignedKMMap[mId] = [];
    assignedKMMap[mId].push({ assignmentId: a?.id ?? '', kmName: a?.keyMeasure?.name ?? 'Unknown' });
  });

  const filtered = useMemo(() => {
    return (measurements ?? []).filter((m: MeasurementData) => {
      if (filter !== 'all' && m?.type !== filter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!m?.name?.toLowerCase()?.includes(q)) return false;
      }
      return true;
    });
  }, [measurements, filter, searchQuery]);

  const hasSelected = safeSelectedIds?.size > 0;

  const typeIcon = (type: string, color: string) => {
    const iconClass = 'w-3.5 h-3.5 flex-shrink-0';
    switch (type) {
      case 'area': return <Square className={iconClass} style={{ color }} />;
      case 'linear': return <Minus className={iconClass} style={{ color }} />;
      case 'count': return <Circle className={iconClass} style={{ color }} />;
      default: return <Square className={iconClass} style={{ color }} />;
    }
  };

  const typeLabel = (type: string) => {
    switch (type) {
      case 'area': return 'AREA';
      case 'linear': return 'LINEAR';
      case 'count': return 'COUNT';
      default: return 'AREA';
    }
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Search bar + filter icon */}
      <div className="px-2 py-1.5 border-b border-gray-100 flex items-center gap-1.5">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
          <Input
            type="text"
            placeholder="Search ..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-7 pl-7 text-xs"
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className={`h-7 w-7 p-0 flex-shrink-0 ${filter !== 'all' ? 'border-blue-400 bg-blue-50 text-blue-600' : ''}`}
              title="Filter by type"
            >
              <Filter className="w-3.5 h-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            {(['all', 'area', 'linear', 'count'] as FilterType[]).map((f) => (
              <DropdownMenuItem
                key={f}
                onClick={() => setFilter(f)}
                className={`text-xs cursor-pointer ${filter === f ? 'bg-blue-50 text-blue-700 font-medium' : ''}`}
              >
                {f === 'all' ? 'All Types' : f.charAt(0).toUpperCase() + f.slice(1)}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Multi-select Actions Bar */}
      {hasSelected && (
        <div className="px-2 py-1.5 bg-blue-50 border-b border-blue-100 flex items-center gap-2">
          <button
            onClick={onDeselectAll}
            className="text-[11px] text-blue-600 hover:text-blue-800 font-medium underline underline-offset-2"
          >
            Clear Selection ({safeSelectedIds?.size ?? 0})
          </button>
          <div className="flex-1" />
          <button
            onClick={(e) => {
              const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
              onAssign?.([...safeSelectedIds], rect);
            }}
            className="text-[11px] font-medium text-white bg-blue-600 hover:bg-blue-700 px-2.5 py-1 rounded transition-colors"
          >
            Assign Selected
          </button>
        </div>
      )}

      {/* Measurement List - Flat */}
      <div className="flex-1 overflow-y-auto">
        {(filtered ?? []).length === 0 ? (
          <div className="px-3 py-8 text-center">
            <p className="text-xs text-gray-400">No quick measures found.</p>
          </div>
        ) : (
          (filtered ?? []).map((m: MeasurementData) => {
            const isSelected = safeSelectedIds?.has?.(m?.id ?? '');
            const isHovered = hoveredId === m?.id;
            const assignedKMs = assignedKMMap[m?.id ?? ''] ?? [];
            const hasAssign = assignedKMs.length > 0;
            const isAssignActive = activeAssignIconId === m?.id;

            return (
              <QMRow
                key={m?.id}
                m={m}
                isSelected={isSelected}
                isHovered={isHovered}
                isInspected={inspectedQMId === m?.id}
                hasAssign={hasAssign}
                assignedKMs={assignedKMs}
                isAssignActive={isAssignActive}
                typeIcon={typeIcon}
                typeLabel={typeLabel}
                onHover={onHover}
                onToggleSelect={onToggleSelect}
                onToggleVisibility={onToggleVisibility}
                onAssign={onAssign}
                onDelete={onDelete}
                onRename={onRename}
                onDuplicate={onDuplicate}
                onAssignIconClick={(id) => setActiveAssignIconId(activeAssignIconId === id ? null : id)}
                onInspect={(id) => setInspectedQMId(inspectedQMId === id ? null : id)}
              />
            );
          })
        )}
      </div>

      {/* Quick Measure Properties Panel */}
      {inspectedQMId && (() => {
        const inspected = (measurements ?? []).find((m) => m?.id === inspectedQMId);
        if (!inspected || !inspected.isAI) return null;
        return (
          <QMPropertiesPanel
            m={inspected}
            onClose={() => setInspectedQMId(null)}
          />
        );
      })()}
    </div>
  );
}

/* ============== QM Properties Panel ============== */
function QMPropertiesPanel({ m, onClose }: { m: MeasurementData; onClose: () => void }) {
  // Generate synthetic construction properties from measurement data
  const props = useMemo(() => {
    const nameStr = m?.name ?? '';
    const typeStr = m?.type ?? 'area';
    const nameUp = nameStr.toUpperCase();

    // Derive object type from name heuristics
    let objectType = 'General';
    let wallType: 'Interior' | 'Exterior' | null = null;
    let wallAreaLevel = '';
    let width = '';
    let height = '';

    if (nameUp.includes('WALL') || nameUp.includes('WL') || typeStr === 'linear') {
      objectType = 'Wall';
      wallType = nameUp.includes('EXT') ? 'Exterior' : 'Interior';
      width = nameUp.includes('2X6') ? '2x6' : '2x4';
      height = '00 ft';
    } else if (nameUp.includes('FLOOR') || nameUp.includes('FLR')) {
      objectType = 'Floor';
    } else if (nameUp.includes('ROOF') || nameUp.includes('RF')) {
      objectType = 'Roof';
    } else if (nameUp.includes('DOOR') || nameUp.includes('DR')) {
      objectType = 'Door';
    } else if (nameUp.includes('WIN') || nameUp.includes('WN')) {
      objectType = 'Window';
    } else if (nameUp.includes('HEADER') || nameUp.includes('HDR') || nameUp.includes('BEAM')) {
      objectType = 'Header/Beam';
    } else if (typeStr === 'area') {
      objectType = 'Area';
    } else if (typeStr === 'count') {
      objectType = 'Count Item';
    }

    // Derive floor level from name
    if (nameUp.includes('1F') || nameUp.includes('1ST')) wallAreaLevel = '1st Floor';
    else if (nameUp.includes('2F') || nameUp.includes('2ND')) wallAreaLevel = '2nd Floor';
    else if (nameUp.includes('3F') || nameUp.includes('3RD')) wallAreaLevel = '3rd Floor';
    else if (nameUp.includes('BSMT') || nameUp.includes('BASE')) wallAreaLevel = 'Basement';
    else wallAreaLevel = '1st Floor';

    // Generate a synthetic rename suggestion
    const parts = nameStr.split('_').filter(Boolean);
    let renamedTo = '';
    if (parts.length >= 2) {
      renamedTo = parts.map(p => {
        if (p.match(/^\d/)) return p;
        return p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
      }).join('_');
      if (objectType === 'Wall') {
        renamedTo = parts[0] + '_WI_' + parts.slice(1).join('_');
      }
    }

    // Confidence rating based on hash of name
    let conf = 0;
    for (let i = 0; i < nameStr.length; i++) conf += nameStr.charCodeAt(i);
    const confidence = 70 + (conf % 25);

    return { objectType, wallType, wallAreaLevel, width, height, renamedTo, confidence };
  }, [m]);

  const typeStr = m?.type ?? 'area';
  const valueLabel = typeStr === 'linear' ? 'Length' : typeStr === 'area' ? 'Area' : 'Count';

  return (
    <div className="border-t border-gray-200 bg-white flex-shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-100">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span className="text-xs font-semibold text-gray-800">Quick Measure Properties</span>
        </div>
        <button
          onClick={onClose}
          className="p-0.5 rounded hover:bg-gray-200 transition-colors"
          title="Close properties"
        >
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </button>
      </div>

      {/* Properties Grid */}
      <div className="px-3 py-2 space-y-1.5 max-h-[260px] overflow-y-auto">
        {/* Name */}
        <div className="flex items-start gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0 pt-0.5">Name</span>
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="text-[11px] text-gray-400 line-through font-mono truncate">{m?.name ?? ''}</span>
            {props.renamedTo && props.renamedTo !== m?.name && (
              <span className="text-[11px] text-emerald-600 font-semibold font-mono truncate">{props.renamedTo}</span>
            )}
          </div>
        </div>

        {/* Measurement Type */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Measurement</span>
          <div className="flex items-center gap-1">
            <span className="text-[11px] text-gray-700 font-medium capitalize">{typeStr}</span>
            {typeStr === 'linear' && <Minus className="w-3 h-3 text-gray-500" />}
            {typeStr === 'area' && <Square className="w-3 h-3 text-gray-500" />}
            {typeStr === 'count' && <Circle className="w-3 h-3 text-gray-500" />}
          </div>
        </div>

        {/* Value */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">{valueLabel}</span>
          <span className="text-[11px] text-gray-700 font-mono">{formatValue(m?.value ?? 0, typeStr)} {m?.unit ?? ''}</span>
        </div>

        {/* Color */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Color</span>
          <div className="w-4 h-4 rounded border border-black/10" style={{ backgroundColor: m?.color ?? '#999' }} />
        </div>

        {/* Object Type */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Object Type</span>
          <span className="text-[11px] text-gray-700 font-semibold underline underline-offset-2">{props.objectType}</span>
        </div>

        {/* Wall Area by/Level */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Wall Area by/Level</span>
          <span className="text-[11px] text-gray-700 font-semibold underline underline-offset-2">{props.wallAreaLevel}</span>
        </div>

        {/* Wall Type (only for walls) */}
        {props.wallType && (
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Wall Type</span>
            <div className="flex items-center gap-1.5">
              <span className={`text-[11px] font-medium ${
                props.wallType === 'Exterior' ? 'text-gray-700' : 'text-gray-400 line-through'
              }`}>Exterior</span>
              <span className={`text-[11px] font-semibold ${
                props.wallType === 'Interior' ? 'text-emerald-600' : 'text-gray-400 line-through'
              }`}>Interior</span>
            </div>
          </div>
        )}

        {/* Width (only for walls) */}
        {props.width && (
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Width</span>
            <span className="text-[11px] text-gray-700 font-semibold underline underline-offset-2">{props.width}</span>
          </div>
        )}

        {/* Height (only for walls) */}
        {props.height && (
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-400 font-medium w-24 flex-shrink-0">Height</span>
            <span className="text-[11px] text-gray-700 font-semibold underline underline-offset-2">{props.height}</span>
          </div>
        )}
      </div>

      {/* Confidence Rating */}
      <div className="px-3 py-2 border-t border-gray-100 bg-gray-50">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-gray-700">Confidence Rating:</span>
          <span className={`text-[11px] font-bold ${
            props.confidence >= 85 ? 'text-emerald-600' : props.confidence >= 70 ? 'text-amber-600' : 'text-red-500'
          }`}>{props.confidence}%</span>
        </div>
      </div>
    </div>
  );
}

/* ============== Synthetic Segments ============== */
function generateSegments(m: MeasurementData): { index: number; value: number; unit: string }[] {
  const count = m?.segmentCount ?? 1;
  if (count <= 1) return [];
  const total = m?.value ?? 0;
  const unit = m?.unit ?? '';
  const segments: { index: number; value: number; unit: string }[] = [];
  // Distribute total across segments with slight variation
  let remaining = total;
  for (let i = 0; i < count; i++) {
    if (i === count - 1) {
      segments.push({ index: i + 1, value: Math.max(0, remaining), unit });
    } else {
      const avg = remaining / (count - i);
      // Vary by ±20% around the average
      const variation = 0.8 + (((i * 7 + 3) % 10) / 10) * 0.4;
      const segVal = Math.max(0.01, avg * variation);
      segments.push({ index: i + 1, value: segVal, unit });
      remaining -= segVal;
    }
  }
  return segments;
}

/* ============== QM Row ============== */
function QMRow({
  m,
  isSelected,
  isHovered,
  isInspected,
  hasAssign,
  assignedKMs,
  isAssignActive,
  typeIcon,
  typeLabel,
  onHover,
  onToggleSelect,
  onToggleVisibility,
  onAssign,
  onDelete,
  onRename,
  onDuplicate,
  onAssignIconClick,
  onInspect,
}: {
  m: MeasurementData;
  isSelected: boolean;
  isHovered: boolean;
  isInspected: boolean;
  hasAssign: boolean;
  assignedKMs: { assignmentId: string; kmName: string }[];
  isAssignActive: boolean;
  typeIcon: (type: string, color: string) => React.ReactNode;
  typeLabel: (type: string) => string;
  onHover: (id: string | null) => void;
  onToggleSelect: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  onAssign: (ids: string[], anchorRect?: DOMRect) => void;
  onDelete: (ids: string[]) => void;
  onRename: (id: string, name: string) => void;
  onDuplicate: (id: string) => void;
  onAssignIconClick: (id: string) => void;
  onInspect: (id: string) => void;
}) {
  const [editingName, setEditingName] = useState(false);
  const [editName, setEditName] = useState('');
  const [segmentsExpanded, setSegmentsExpanded] = useState(false);

  const hasSegments = (m?.segmentCount ?? 0) > 1;
  const segments = useMemo(() => hasSegments ? generateSegments(m) : [], [m, hasSegments]);

  const finishEdit = () => {
    if (editName?.trim?.()) onRename?.(m?.id ?? '', editName.trim());
    setEditingName(false);
    setEditName('');
  };

  return (
    <div>
      <div
        className={`group flex items-center gap-1 px-1.5 py-[5px] border-b border-gray-50 cursor-default transition-colors duration-100 ${
          isInspected ? 'bg-amber-50/70 border-l-2 border-l-amber-400' : isAssignActive ? 'bg-emerald-50' : isHovered ? 'bg-blue-50/60' : isSelected ? 'bg-blue-50/40' : 'hover:bg-gray-50/70'
        }`}
        onMouseEnter={() => onHover?.(m?.id ?? null)}
        onMouseLeave={() => onHover?.(null)}
        onClick={() => { if (m?.isAI) onInspect(m?.id ?? ''); }}
      >
        {/* Checkbox */}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleSelect?.(m?.id ?? ''); }}
          className={`w-4 h-4 border rounded flex items-center justify-center flex-shrink-0 transition-colors ${
            isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          {isSelected && (
            <svg className="w-3 h-3 text-white" viewBox="0 0 12 12" fill="none">
              <path d="M2 6L5 9L10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </button>

        {/* Color dot */}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleVisibility?.(m?.id ?? ''); }}
          className="flex-shrink-0 p-0.5 rounded transition-colors hover:bg-gray-200"
        >
          {m?.visible !== false ? (
            <div className="w-2.5 h-2.5 rounded-full border border-black/10" style={{ backgroundColor: m?.color ?? '#999' }} />
          ) : (
            <EyeOff className="w-2.5 h-2.5 text-gray-300" />
          )}
        </button>

        {/* Type Icon */}
        {typeIcon(m?.type ?? 'area', m?.color ?? '#999')}

        {/* Name */}
        {editingName ? (
          <Input
            type="text"
            value={editName}
            onChange={(e) => setEditName(e?.target?.value ?? '')}
            onBlur={finishEdit}
            onKeyDown={(e) => {
              if (e?.key === 'Enter') finishEdit();
              if (e?.key === 'Escape') { setEditingName(false); setEditName(''); }
            }}
            autoFocus
            className="h-5 text-[11px] px-1 flex-1 min-w-0"
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span className="text-[11px] font-semibold text-gray-700 truncate min-w-0" title={m?.name ?? ''}>
            {m?.name ?? typeLabel(m?.type ?? 'area')}
          </span>
        )}

        {/* Segment count — clickable to expand */}
        {!editingName && hasSegments && (
          <button
            onClick={(e) => { e.stopPropagation(); setSegmentsExpanded(!segmentsExpanded); }}
            className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded hover:bg-gray-100 transition-colors flex-shrink-0"
            title={`${m?.segmentCount} segments — click to ${segmentsExpanded ? 'collapse' : 'expand'}`}
          >
            {segmentsExpanded ? (
              <ChevronDown className="w-3 h-3 text-gray-400" />
            ) : (
              <ChevronRight className="w-3 h-3 text-gray-400" />
            )}
            <span className="text-[9px] font-bold text-gray-500">{m?.segmentCount}</span>
          </button>
        )}

        {/* Status icons: AI sparkle + QM-Assign (always visible, between name and value) */}
        {!editingName && (m?.isAI || hasAssign) && (
          <div className="flex items-center gap-0.5 flex-shrink-0">
            {m?.isAI && (
              <span title="Auto-Takeoff" className="flex items-center">
                <Sparkles className="w-3 h-3 text-amber-500" />
              </span>
            )}
            {hasAssign && (
              <span
                className={`linked-icon relative flex items-center cursor-pointer transition-colors ${
                  isAssignActive ? 'text-emerald-600' : 'text-emerald-500 hover:text-emerald-600'
                }`}
                title={isAssignActive ? undefined : `Assigned to: ${assignedKMs.map(a => a.kmName).join(', ')}`}
                onClick={(e) => { e.stopPropagation(); onAssignIconClick(m?.id ?? ''); }}
              >
                <GitCompareArrows className="w-3 h-3" />
                {/* Tooltip on hover showing KM list */}
                {isAssignActive && (
                  <div className="absolute right-0 top-full mt-1 z-50 bg-white border border-gray-200 rounded shadow-lg px-2 py-1.5 min-w-[140px] whitespace-nowrap">
                    <p className="text-[10px] text-gray-400 font-medium mb-0.5">Assigned to:</p>
                    {assignedKMs.map((a, i) => (
                      <p key={i} className="text-[11px] text-emerald-700 font-semibold">{a.kmName}</p>
                    ))}
                  </div>
                )}
              </span>
            )}
          </div>
        )}

        {/* Spacer */}
        <div className="flex-1 min-w-0" />

        {/* Value + unit (hidden on hover, replaced by actions) */}
        <span className="text-[11px] font-mono text-gray-500 whitespace-nowrap flex-shrink-0 group-hover:hidden">
          {formatValue(m?.value ?? 0, m?.type ?? 'area')} {m?.unit ?? ''}
        </span>

        {/* Hover actions: Assign button + Ellipsis menu */}
        <div className="hidden group-hover:flex items-center gap-0.5 flex-shrink-0">
          <button
            onClick={(e) => {
              e.stopPropagation();
              const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
              onAssign?.([m?.id ?? ''], rect);
            }}
            className="text-[10px] font-medium text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-1.5 py-0.5 rounded transition-colors"
          >
            Assign
          </button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className="p-0.5 rounded hover:bg-gray-200 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="w-3.5 h-3.5 text-gray-500" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem
                onClick={(e) => { e.stopPropagation(); setEditingName(true); setEditName(m?.name ?? ''); }}
                className="text-xs cursor-pointer gap-2"
              >
                <Pencil className="w-3 h-3" /> Edit Properties
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={(e) => { e.stopPropagation(); onDelete?.([m?.id ?? '']); }}
                className="text-xs cursor-pointer gap-2 text-red-600 focus:text-red-600"
              >
                <Trash2 className="w-3 h-3" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Collapsible segment list */}
      {segmentsExpanded && hasSegments && (
        <div className="bg-gray-50/80 border-b border-gray-100">
          <div className="pl-9 pr-3 py-1">
            <div className="text-[9px] font-semibold text-gray-400 uppercase tracking-wider mb-0.5">
              Segments ({segments.length})
            </div>
            {segments.map((seg) => (
              <div
                key={seg.index}
                className="flex items-center gap-2 py-[3px] text-[10px]"
              >
                <div
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0 opacity-60"
                  style={{ backgroundColor: m?.color ?? '#999' }}
                />
                <span className="text-gray-500 font-medium">Seg {seg.index}</span>
                <div className="flex-1" />
                <span className="font-mono text-gray-500">
                  {formatValue(seg.value, m?.type ?? 'area')} {seg.unit}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function formatValue(value: number, type: string): string {
  if (type === 'count') return String(Math.round(value ?? 0));
  return (value ?? 0)?.toFixed?.(2) ?? '0.00';
}
