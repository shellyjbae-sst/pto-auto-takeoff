export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const assignments = await prisma.assignment.findMany({
      include: {
        measurement: true,
        keyMeasure: true,
        section: true,
        use: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(assignments);
  } catch (error: any) {
    console.error('GET assignments error:', error);
    return NextResponse.json({ error: 'Failed to fetch assignments' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { measurementIds, keyMeasureId, sectionId } = await request.json();
    const results = [];
    for (const measurementId of (measurementIds ?? [])) {
      const assignment = await prisma.assignment.upsert({
        where: { measurementId_keyMeasureId: { measurementId, keyMeasureId } },
        update: { sectionId: sectionId || null, fromQuickMeasure: true },
        create: { measurementId, keyMeasureId, sectionId: sectionId || null, fromQuickMeasure: true },
        include: { measurement: true, keyMeasure: true, section: true, use: true },
      });
      results.push(assignment);
    }
    return NextResponse.json(results, { status: 201 });
  } catch (error: any) {
    console.error('POST assignment error:', error);
    return NextResponse.json({ error: 'Failed to create assignment' }, { status: 500 });
  }
}
