# AI Takeoff 2.0 — Feature Exploration & Working Document

**Source of Truth:** PRD v2.0 AI-Powered Residential Material Takeoff (Feb 2026)  
**Status:** Working draft for PM & Engineering discussion  
**Last updated:** May 2026

---

## Context

AI Takeoff 2.0 introduces an AI-assisted, human-in-the-loop takeoff experience embedded directly into Pipeline LBM and SST Takeoff. The system uses computer vision and ML models trained on North American wood-framed residential plans to automatically generate editable quantities for core assemblies.

**Primary goal:** Reduce estimator effort by ≥50% and unlock scalable residential estimating through AI-assisted material takeoff.

**Core principle:** Estimators remain in the loop. AI augments but does not replace human judgment. Design emphasizes transparency, not automation opacity.

**User personas:**
- **Residential Estimator** — Primary user performing takeoffs under time pressure; values speed, accuracy, and control
- **AI Trainer (Estimator SME)** — Power user responsible for validating AI output and providing structured feedback
- **Sales / Dealer Support** — Downstream consumer of estimates; benefits from faster turnaround

---

## Phased Roadmap (from PRD)

- **Phase 0** — Discovery & Architecture → Baseline metrics, integration design
- **Phase 1A (MF POC)** — Wall Openings – Header module; Floor Framing Layout + Hardware modules → ≥80% accuracy, production-ready SF + MF takeoff
- **Phase 1B (SF GA)** — Existing modules trained and enhanced for SF General Availability → ≥85% accuracy, production-ready SF takeoff
- **Phase 1C** — MF Training & enhancements for Existing Modules → Expanded coverage, ≥85% existing module accuracy for SF + MF plans
- **Phase 1D (MF GA)** — Rated Walls → ≥80% accuracy, production-ready MF takeoff
- **Future** — Advanced Capabilities → Separate initiative / SOW

---

## 1) AI Assembly Modules (What the AI Detects)

The PRD defines specific structural and enclosure assemblies the AI will be trained to detect, phased over time. This is the backbone of the system — what models exist determines what the rest of the workflow operates on.

### Existing Modules (Enhance for SF + MF)

**Sheet Name**  
Existing module. Validate performance on MF plans.  
*Question: What's the current accuracy on MF plans? Is there a validation set?*

**Sheet Scale**  
Existing module enhanced to include state scale validation by cross-referencing the state scale on plans by measuring stated vertical and horizontal dimensions. Use the longest stated dimension for both axes. SF and MF plans.  
*Question: How often do plans have incorrect or missing scale? What's the fallback when scale can't be determined?*

**Floor Area (By Floor / By Room)**  
Existing module also trained on and enhanced for Multifamily plans.  
*Question: How does the model differentiate rooms on open floor plans? Does it use room labels from the drawing or infer boundaries?*

**Wall Linear**  
- Exterior Walls (Framing Width, Framing Height, Species Agnostic) — existing module enhanced for MF
- Interior Walls (Framing Width, Framing Height, Species Agnostic) — existing module enhanced for MF  
*Question: How does the model determine framing width and height — from wall schedule, dimension annotations, or inference? What "Species Agnostic" means in practice — does the estimator fill in species later?*

**Wall Openings (doors, windows, garage doors, wrapped openings)**  
Existing module trained on and enhanced for MF plans.  
*Question: Does the model classify opening type (single door vs double vs sliding), or just detect the opening? Does it read door/window schedules?*

**Roof Area + Linear**  
Existing module trained on and enhanced for MF plans. Add over-frame option?  
*Question: What does "over frame option" mean concretely — different measurement method for over-frame vs conventionally framed roofs?*

**Roof Volume**  
Existing module trained on and enhanced for MF plans. Simple heel / ceiling conditions only.  
*Question: APIs to support Truss Quick Quote in CM products — is this a dependency or a nice-to-have integration?*

### Net New Modules

**Headers and Beams**  
- Headers for doors, windows, and garage doors
- Beams for wrapped openings  
*Question: Does the model size headers/beams or just detect their presence? Does it read span tables or detail callouts?*

**Floor Framing Layout**  
- Measure area of separate "structural regions"
- Include the depth of the floor system for each structural region
- Layout floor framing members: Joists by type and size, Rim Joists by type and size, Floor Truss
- Total length by type, count of same type and length of framing members
- Human-in-the-loop entry for plans without Structural Framing sheets
- Read and trace Structural Framing sheets  
*Question: For plans without structural framing sheets, what does the human-in-the-loop entry look like — is the estimator drawing regions manually and specifying framing, or are we suggesting based on floor plan layout?*

**Floor Framing Hardware**  
- Count framing hardware associated to the floor structure: Joist Hangers, Anchor Bolts, Splice Plates(?)
- Human-in-the-loop entry for standard offering
- Reads details and applies logic to applicable plan views for enhanced offering
- No engineering — only reading what is on the plan and making reasonable assumptions regarding detail placement. Requires human validation.  
*Question: "Standard offering" vs "enhanced offering" — what's the distinction in terms of user experience? Is the standard offering manual counting and enhanced is AI-assisted?*

**Rated Walls Linear (MF only?)**  
- Rating Type, Framing Width, Framing Height
- e.g., Fire, Shear, Sound
- Uses Wall Schedule if present
- Identifies all walls on schedule  
*Question: Is this MF-only or does it apply to SF as well (e.g., shear walls in seismic zones)? How does the model handle plans without wall schedules?*

---

## 2) Pre-Conditioning (What the Estimator Chooses Before Running AI)

**Goal:** Let estimators control which models and settings run so outputs match their needs and budget.

The PRD calls out "Assembly Selection" as a High-importance functional requirement: "As an estimator, I can choose which assemblies to run (individually or en masse)."

### Core Controls

**Assembly selection**  
Estimators choose which AI modules to run — individually (just Wall Openings) or en masse (full structural + enclosure). This maps directly to the assembly modules in Section 1.  
*Question: Should the UI present assemblies individually or as logical groups (e.g., "Framing" = walls + floor + headers, "Enclosure" = roof + openings)? Can assemblies be run incrementally — run walls first, then add headers later on the same project?*

**Sheet / scope selection**  
Which sheets to include: All, specific sheets, or a selected region on a single sheet. Estimators often know which sheets contain structural info and want to skip irrelevant pages.  
*Question: For MF projects with many sheets, is there a need for sheet-type filtering (e.g., "all floor plans" vs "all elevations") or is manual selection sufficient?*

**Run mode (quality vs speed)**  
Fast (lower accuracy, cheaper), Balanced, High Accuracy (longer runtime). The PRD sets performance SLAs at < 10 minutes per standard SF full model run, < 15 minutes per standard MF.  
*Question: Do run modes map to different model configurations (e.g., lighter model vs full ensemble), or is it about post-processing thoroughness? What's the accuracy delta between Fast and High Accuracy?*

**Granularity / detail level**  
Coarse (bulk counts), Standard, Detailed (per-component attributes). Determines how much metadata each detection carries.  
*Question: Is this per-assembly or global? Could an estimator want detailed walls but coarse floor area?*

**Pre-filters / constraints**  
- Ignore small features under X sq ft
- Exclude by object type (furniture, electrical fixtures)
- Exclude by layer name or annotation type  
*Question: Do our models/parsers expose layer metadata from PDFs today?*

**Templates & presets**  
Save and reuse pre-conditioning configurations (e.g., "Structural Review", "Quick Bid", "Full Takeoff"). Speeds up repeat workflows.  
*Question: Are presets per-user, per-organization, or shareable across teams?*

**Cost / time estimate**  
Show estimated compute cost and run time before executing. The PRD mentions this implicitly through performance SLAs.  
*Question: How is compute cost expressed — tokens, credits, dollars? Is there a budget cap mechanism or just an estimate?*

---

## 3) Review and Triage (Human-in-the-Loop)

**Goal:** Give estimators granular control over what the AI returns and how it's presented. The PRD rates "Manual Edit" as **Critical** and "Visual Overlay" as **High** — editing AI quantities before finalizing is the core workflow.

The PRD's design principles:
- AI outputs appear directly within existing Pipeline LBM / SST Takeoff interfaces
- Quantities are clearly labeled as AI-generated vs manually entered
- Visual cues highlight detected elements (e.g., openings, areas)
- Editing is frictionless and mirrors current estimator workflows
- Design emphasizes transparency, not automation opacity

### Visual Overlay & Annotation

**AI detections overlaid on plans**  
The estimator sees AI-detected elements drawn on top of the original blueprint. This is the primary trust mechanism — the estimator can visually verify that the AI found the right things in the right places.  
*Question: What visual language — colored outlines, shaded regions, pins? Does each assembly type get a distinct style? How dense can overlays get on a busy MF plan before they obscure the drawing?*

**AI-generated vs manually entered labeling**  
Clear visual distinction between quantities the AI produced and quantities the estimator entered or edited. Could be a badge, icon, color treatment, or subtle background.  
*Question: Once an estimator edits an AI value, does it become "manual" or does it retain its AI provenance with an "edited" flag?*

**Annotation controls**  
Toggle AI annotations on/off globally or by assembly type. Label style options: icons only, text labels, color-coded by confidence.  
*Question: Is confidence always available from all models, or only some? What's the confidence format — percentage, tier (High/Med/Low)?*

### Per-Object Metadata

**Confidence score**  
Display a confidence indicator on each AI-generated quantity. Helps estimators prioritize what to review — low-confidence items get reviewed first, high-confidence items can be batch-accepted.  
*Question: What confidence format do our models return — 0–1 float, percentage, categorical? Do all assembly modules return confidence or only some?*

**Model provenance**  
Show which model (and version) produced each detection. Important for the AI Trainer persona who needs to know which model to give feedback about.  
*Question: Provenance granularity — model name only, or model + version + run ID?*

### Inline Editing Actions

These are the core human-in-the-loop interactions. The estimator reviews AI output and takes action:

**Accept**  
Confirm an AI detection is correct. One-click action. Moves the item from "needs review" to "accepted."  

**Edit / Override**  
Modify AI-generated quantities, geometry, or attributes. The PRD says editing must be "frictionless and mirror current estimator workflows" — so inline editing, not a separate editing mode.  
*Question: What's editable — just the quantity value, or also the geometry (shape/bounds on canvas), type classification, and attributes? How much of the current manual editing workflow can we reuse?*

**Reject / Dismiss**  
Remove an incorrect detection. Should be easy to undo in case of accidental rejection.  

**Flag for review**  
Mark a detection as uncertain or problematic — escalate to another estimator or the AI Trainer. Optionally attach a note or category (wrong type, bad geometry, needs field verification).  
*Question: What are the flag categories — free-text, predefined reasons, or both? Does flagging trigger a notification or is it passive?*

**Merge**  
Combine two or more overlapping or duplicate detections into one. Relevant when multiple assembly models detect the same physical element.  
*Question: Merge logic — does the user pick which detection to keep, or does the system suggest based on confidence? What happens to the metadata of the merged items?*

**Split**  
Separate a detection that incorrectly groups two distinct elements. Interactive split tool on the canvas.  
*Question: How does splitting work geometrically — line bisection, polygon editing, or manual redraw?*

### Filtering & Search

**Filter by type, confidence, tag, area, model source**  
Narrow down the review list to focus on specific subsets. Essential when an AI run produces hundreds of detections across multiple assembly types.  

**Search by name or code**  
Text search across detection names, types, or mapped Key Measure codes.  

### Batch Actions & Automation

**Batch accept/reject by type**  
"Accept all doors", "Reject all furniture" — bulk operations on filtered or grouped sets. Critical for large MF plans with many repeat elements.  
*Question: Should batch actions operate on currently visible/filtered items only, or all items of that type regardless of filters?*

**Auto-accept threshold**  
Automatically accept detections above a confidence level (e.g., >98%). Configurable per run or as a project default. Dramatically reduces manual review for high-confidence results.  
*Question: Should this run retroactively on existing results or only on new incoming results? Should there be an "undo auto-accept" option?*

### Grouping & Deduplication

**Grouping / aggregation**  
Group detections by type, assembly, floor, or sheet. Toggle between individual elements (12 door rows) and consolidated bundles ("12× Door, Single" as one row).  
*Question: Visual-only grouping (UI collapsing) or does it affect the data model?*

**Deduplication controls**  
Merge overlapping detections from different models. Split incorrectly merged objects.  
*Question: What overlap threshold triggers a merge suggestion? Should it auto-suggest or require manual initiation?*

### Change Tracking

**Original vs AI overlay views**  
Toggle between: original blueprint only, AI overlay only, or combined view. Lets estimators compare before/after.  

**Change log per detection**  
Timeline of events for each detection: created → edited → accepted, with timestamps. Expandable in a detail panel.  

---

## 4) Mapping AI Detections → Key Measures / Products

**Goal:** Connect AI-detected quantities to the project's formal cost-code structure (Key Measures, Sections, Products in Pipeline LBM).

This is where AI output becomes actionable for estimating. The AI detects "14 LF of exterior wall, 2×6, 9'" — but the estimator needs to map that to the right Key Measure line item like `EW_2x6_9`.

### Core Mapping

**Single and bulk QM → KM assignment**  
Assign one or many Quick Measures to a Key Measure via the existing popover workflow. Already partially built.  

**Batch mapping by type**  
"Map all detected exterior doors to KM: WD_SINGLE_J6" — type-level assignment that applies to all QMs of a given detection type.  
*Question: What happens to QMs of that type already assigned to a different KM — override, skip, or prompt?*

**Batch mapping by sheet**  
Map all QMs on a specific sheet to a default KM set. Useful for MF projects with identical floor layouts.  

### Smart Suggestions

**Ranked KM suggestions**  
When assigning a QM, suggest Key Measures ranked by learned patterns — previous mappings for similar types, same-project history, organization-wide patterns.  
*Question: Start with simple heuristics (same type → same KM used last time) or invest in ML-based suggestions from the start? ML suggestions need training data from the feedback loop (Section 5).*

**Mapping confidence display**  
Show how confident the system is in each KM suggestion. Helps estimators trust or override recommendations.  

### Conflict Resolution

**Duplicate / overlapping markups**  
Detect when the same physical element has multiple QMs. Highlight the conflict and suggest merging or choosing one.  

**Unit mismatches**  
Flag when a QM's unit doesn't match the KM's expected unit (e.g., SF area assigned to a LF Key Measure). Show a warning before allowing.  

**Unit normalization**  
Auto-convert units to match KM expectations when possible (e.g., inches → feet).  
*Question: Automatic or require user confirmation?*

---

## 5) Feedback Capture & Model Training

**Goal:** Capture estimator corrections to improve future AI suggestions and model accuracy.

The PRD lists "Feedback Capture" as Medium importance: "As an AI Trainer, I can submit corrections to improve models." It also calls out "Feedback capture via designated 'AI Trainer' workflows" as in-scope.

### Event Capture

**Log accept / edit / reject / flag events**  
Every estimator action on an AI detection is recorded: detection ID, action type, before/after state (for edits), timestamp, user identity, and optional reason (for rejects/flags).  
*Question: Where does this data live — same database, separate analytics store, or exported to an external ML pipeline? What's the data retention policy?*

### AI Trainer Workflow

**Designated "AI Trainer" role**  
The PRD calls out a specific AI Trainer (Estimator SME) persona. This user validates AI output and provides structured feedback that goes beyond simple accept/reject — they might annotate why a detection was wrong, reclassify it, or mark it as a training exemplar.  
*Question: What does the AI Trainer workflow look like concretely — is it a separate UI/mode, or is it the same review workflow with extra options? How do we identify and route items to AI Trainers?*

### Training Pipeline

**Training data export**  
Export captured events for model fine-tuning. Filtered by date range, project, model, or assembly type.  

**Model version registry**  
Track which model version produced which detections. When models are updated, compare old vs new results.  

**Model changelog**  
Surface model updates to users — what changed, expected improvements, known issues.  
*Question: Is this user-facing (estimators see it) or internal (AI Trainers / engineering only)?*

**Auto-learn toggle**  
Per-project opt-in to save corrections for retraining.  
*Question: Privacy and data ownership — do customers own their correction data? Can they opt out or delete?*

---

## 6) Audit Trail

**Goal:** Full traceability for every markup — who changed what, when, and which model was involved.

**Per-markup history**  
Timeline of events for each detection: created → edited → assigned → accepted → rejected. Expandable in a detail panel.  

**User attribution**  
Who performed each action (user ID, name, role).  

**Model provenance**  
Which model + version created the initial detection. Immutable.  

**Audit log export**  
Export full audit trail per sheet or project as PDF or CSV.  

*Question: Is audit trail required for regulatory compliance, or is it a trust/transparency feature? The answer affects how rigorous the implementation needs to be.*

---

## Explicitly Out of Scope (from PRD)

These are called out in the PRD as not part of AI Takeoff 2.0:

- Full automation without estimator review
- Front-end redesign beyond required integration points
- Additional MF Takeoff Services requirements (future phase)
- Roof Framing Layout / Hardware (future phase)
- Stair takeoff (future phase)
- Exterior Finishes takeoff (future phase)
- Interior Finishes takeoff
- Delta comparisons
- 2D→3D production-ready conversion features
- MEP takeoff
- Producing a sellable bill-of-materials
- Pricing, quoting, or downstream ERP logic changes

---

## Non-Functional Requirements (from PRD)

- **Accuracy:** ≥90% F1 initial, ≥95% for mature models; ≥80% net new modules, ≥85% for mature modules
- **Performance:** < 10 minutes per standard SF full model run; < 15 minutes per standard MF full model run (to be validated)
- **Scalability:** 5,000 projects/month (Phase 1), 8,000–10,000 by end of 2027
- **Reliability:** High availability, fault-tolerant API integration
- **Security:** Encrypted data in transit and at rest; isolated cloud infrastructure
- **Usability:** Editable, explainable AI outputs embedded in existing workflows

---

## Success Metrics (from PRD)

- ≥50% reduction in estimator time per SF + MF takeoff
- Model accuracy targets met per phase (F1 score)
- Module accuracy and standard deviation targets met per phase
- Estimator adoption rate of AI-assisted takeoff
- Positive qualitative feedback from estimator SMEs
- System supports target monthly project volumes

---

## Dependencies (from PRD)

- API documentation and monetization support by Platform, IT, and Finance
- Access to sufficient training and validation datasets
- SME availability for UAT and feedback cycles
- Pipeline LBM engineering capacity for front-end and integration work
- Clear acceptance criteria per phase for go/no-go decisions
- SST provides access to estimator SMEs and an identified AI Trainer group
- Training data (plans/drawings) is sourced, approved, and labeled by SST at a velocity that matches development capacities and go-to-market expectations

---

## Open Questions

### Scope & Phases

- What's the concrete feature set for each phase from a front-end perspective? The PRD defines phases by assembly module, but the review/triage/mapping workflows cut across all phases.
- Which front-end workflows must ship with Phase 1A vs can follow in 1B/1C?
- Is the AI Trainer workflow a Phase 1 requirement or can it come later once the basic review loop is established?

### AI Capabilities & Integration

- What's the API contract between Pipeline LBM and the AI inference service? Request/response format, async vs sync, webhook callbacks?
- What metadata does each model return — just geometry + type, or also confidence, attributes (framing width, height), and provenance?
- How do models handle multi-sheet context (e.g., floor plan references elevation for roof details)?
- Expected latency per sheet per model — impacts whether we need a progress/polling UX or can return results synchronously.

### Cost & Tokens

- How will AI processing be tokenized and measured? Per-sheet, per-model-run, per-detection?
- Per-project vs per-assembly pricing — affects how we present cost estimates.
- Token budget controls — hard cap that blocks runs, or soft warning?

### UX & Workflow

- Review queue as a dedicated mode vs integrated into the existing QM panel — which is primary?
- How does the estimator's current manual workflow look in Pipeline LBM today, and where exactly do AI outputs inject into it?
- For MF projects with 50+ sheets, what's the expected review workflow — sheet by sheet, or a cross-project review queue?
- How do we handle partial runs — e.g., AI run completed for walls but not yet for openings on the same sheet?

---

## Prototype Status (Our Takeoff App)

For context, here's what's built in the prototype relative to PRD requirements:

**Shipped:**
- Auto-Takeoff initiation wizard (assembly selection, scope, run mode, detail level, pre-filters, presets, cost estimate) — maps to PRD's "Assembly Selection" and pre-conditioning workflow
- QM → KM assignment (single + bulk) via popover — maps to PRD's mapping workflow
- Canvas with visual overlay of markups — maps to PRD's "Visual Overlay" requirement
- Canvas filter legend (source/type/section visibility controls)
- Per-item visibility toggle with two-layer model (user toggle + canvas filters)

**Not yet built:**
- Human-in-the-loop review actions (accept/reject/edit/flag/merge/split)
- Confidence scores and model provenance on QM rows
- Filtering by confidence, tag, model source
- Batch accept/reject by type
- Auto-accept threshold
- AI Trainer feedback workflow
- Audit trail / change log
- Smart mapping suggestions
- Conflict resolution and unit normalization

---

*This document is a living artifact. Update as decisions are made and requirements are refined.*
