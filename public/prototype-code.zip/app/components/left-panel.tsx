'use client';

import React, { useState, useMemo } from 'react';
import { SheetData, MeasurementData, AssignmentData, KeyMeasureData } from '@/types/takeoff';
import {
  ChevronRight,
  ChevronDown,
  FileText,
  Square,
  Minus,
  Circle,
  Search,
  Pencil,
  Upload,
  Ruler,
  Sparkles,
} from 'lucide-react';
import { Input } from '@/components/ui/input';

interface LeftPanelProps {
  sheets: SheetData[];
  measurements: MeasurementData[];
  assignments: AssignmentData[];
  keyMeasures: KeyMeasureData[];
  activeSheetId: string | null;
  onSelectSheet: (id: string) => void;
  hoveredId: string | null;
  onHover: (id: string | null) => void;
  onToggleVisibility: (id: string) => void;
  onImportPlan?: () => void;
  onDetectScale?: (sheet: SheetData) => void;
}

export default function LeftPanel({
  sheets,
  measurements,
  assignments,
  keyMeasures,
  activeSheetId,
  onSelectSheet,
  hoveredId,
  onHover,
  onToggleVisibility,
  onImportPlan,
  onDetectScale,
}: LeftPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSheets, setExpandedSheets] = useState<Set<string>>(() => {
    return new Set(activeSheetId ? [activeSheetId] : []);
  });

  // When activeSheetId changes, auto-expand it
  React.useEffect(() => {
    if (activeSheetId) {
      setExpandedSheets((prev) => {
        const next = new Set(prev);
        next.add(activeSheetId);
        return next;
      });
    }
  }, [activeSheetId]);

  // Build KM name map for display
  const kmMap = useMemo(() => {
    const map = new Map<string, KeyMeasureData>();
    (keyMeasures ?? []).forEach((km) => map.set(km.id, km));
    return map;
  }, [keyMeasures]);

  // Get measurements for a given sheet
  const getMeasurementsForSheet = useMemo(() => {
    const bySheet = new Map<string, MeasurementData[]>();
    (measurements ?? []).forEach((m) => {
      if (m.sheetId) {
        const list = bySheet.get(m.sheetId) || [];
        list.push(m);
        bySheet.set(m.sheetId, list);
      }
    });
    return bySheet;
  }, [measurements]);

  // Get assignment for a measurement (to show KM name)
  const assignmentByMeasId = useMemo(() => {
    const map = new Map<string, AssignmentData>();
    (assignments ?? []).forEach((a) => {
      map.set(a.measurementId, a);
    });
    return map;
  }, [assignments]);

  const filteredSheets = useMemo(() => {
    if (!searchQuery.trim()) return sheets;
    const q = searchQuery.toLowerCase();
    return sheets.filter((s) => s.name.toLowerCase().includes(q));
  }, [sheets, searchQuery]);

  const toggleSheet = (id: string) => {
    setExpandedSheets((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const typeIcon = (type: string, color: string) => {
    const iconClass = 'w-3 h-3 flex-shrink-0';
    switch (type) {
      case 'area': return <Square className={iconClass} style={{ color }} />;
      case 'linear': return <Minus className={iconClass} style={{ color }} />;
      case 'count': return <Circle className={iconClass} style={{ color }} />;
      default: return <Square className={iconClass} style={{ color }} />;
    }
  };

  const formatValue = (value: number, type: string): string => {
    if (type === 'count') return String(Math.round(value ?? 0));
    return (value ?? 0)?.toFixed?.(2) ?? '0.00';
  };

  return (
    <div className="w-[280px] min-w-[280px] bg-white border-r border-gray-200 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2.5 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
        <Pencil className="w-3.5 h-3.5 text-blue-600" />
        <h3 className="text-sm font-semibold text-gray-800 flex-1">Sheets</h3>
        <span className="text-xs text-gray-400 font-mono">{sheets.length}</span>
        <button
          onClick={onImportPlan}
          className="flex items-center gap-1 px-2 py-1 text-[10px] font-medium text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors"
          title="Import Plan PDF"
        >
          <Upload className="w-3 h-3" />
          Import
        </button>
      </div>

      {/* Search */}
      <div className="px-3 py-2 border-b border-gray-100">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
          <Input
            type="text"
            placeholder="Search ..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 pl-8 text-xs"
          />
        </div>
      </div>

      {/* Sheet list */}
      <div className="flex-1 overflow-y-auto">
        {filteredSheets.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <p className="text-xs text-gray-400">No sheets found.</p>
          </div>
        ) : (
          filteredSheets.map((sheet) => {
            const isActive = activeSheetId === sheet.id;
            const isExpanded = expandedSheets.has(sheet.id);
            const sheetMeasurements = getMeasurementsForSheet.get(sheet.id) || [];
            const measCount = sheetMeasurements.length;

            return (
              <div key={sheet.id} className="border-b border-gray-100">
                {/* Sheet row */}
                <div
                  className={`group/sheet flex items-center gap-1.5 px-3 py-2 cursor-pointer transition-colors ${
                    isActive ? 'bg-blue-50' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => {
                    onSelectSheet(sheet.id);
                    toggleSheet(sheet.id);
                  }}
                >
                  {measCount > 0 ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSheet(sheet.id);
                      }}
                      className="flex-shrink-0 p-0.5"
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                      )}
                    </button>
                  ) : (
                    <div className="w-4.5 flex-shrink-0" />
                  )}
                  <FileText className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className={`text-xs truncate ${isActive ? 'text-blue-700 font-semibold' : 'text-gray-700 font-medium'}`}>
                      {sheet.name}
                    </span>
                    <div className="flex items-center gap-1">
                      {sheet.scale && sheet.scale !== 'N/A' ? (
                        <span className="text-[9px] text-gray-400 font-mono flex items-center gap-0.5">
                          <Ruler className="w-2.5 h-2.5" />
                          {sheet.scale}
                        </span>
                      ) : (
                        <span className="text-[9px] text-gray-400 italic">No scale</span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDetectScale?.(sheet);
                        }}
                        className="opacity-0 group-hover/sheet:opacity-100 ml-auto flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-medium text-teal-600 hover:text-teal-800 bg-teal-50 hover:bg-teal-100 rounded transition-all"
                        title="Auto-detect scale with AI"
                      >
                        <Sparkles className="w-2.5 h-2.5" />
                        Scale
                      </button>
                    </div>
                  </div>
                  {measCount > 0 && (
                    <span className="text-[10px] text-gray-400 font-mono flex-shrink-0">{measCount}</span>
                  )}
                </div>

                {/* Measurements under this sheet */}
                {isExpanded && measCount > 0 && (
                  <div className="pb-1">
                    {sheetMeasurements.map((m) => {
                      const assignment = assignmentByMeasId.get(m.id);
                      const km = assignment ? kmMap.get(assignment.keyMeasureId) : null;
                      const isHovered = hoveredId === m.id;
                      const displayName = km ? km.name : m.name;
                      const displayColor = km ? km.color : m.color;

                      return (
                        <div
                          key={m.id}
                          className={`group flex items-center gap-1.5 pl-10 pr-3 py-1.5 cursor-pointer transition-all duration-150 ${
                            isHovered ? 'bg-blue-50/70' : 'hover:bg-gray-50/70'
                          }`}
                          onMouseEnter={() => onHover?.(m.id)}
                          onMouseLeave={() => onHover?.(null)}
                        >
                          {/* Color circle */}
                          <div
                            className="w-3 h-3 rounded-full flex-shrink-0 border border-black/10"
                            style={{ backgroundColor: displayColor }}
                          />

                          {/* Type icon */}
                          {typeIcon(m.type, displayColor)}

                          {/* Name */}
                          <span className="text-[11px] text-gray-700 truncate flex-1 font-mono">
                            {displayName}
                          </span>

                          {/* Value */}
                          <span className="text-[10px] font-mono text-gray-500 whitespace-nowrap flex-shrink-0">
                            {formatValue(m.value, m.type)} {m.unit}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
