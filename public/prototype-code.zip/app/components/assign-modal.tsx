'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { KeyMeasureData, SectionData } from '@/types/takeoff';
import { X, Search, Check } from 'lucide-react';

interface AssignModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (keyMeasureId: string, sectionId: string | null) => void;
  measurementNames: string[];
  anchorRect?: DOMRect | null;
}

export default function AssignModal({ isOpen, onClose, onApply, measurementNames, anchorRect }: AssignModalProps) {
  const [keyMeasures, setKeyMeasures] = useState<KeyMeasureData[]>([]);
  const [sections, setSections] = useState<SectionData[]>([]);
  const [selectedKM, setSelectedKM] = useState<string>('');
  const [selectedSection, setSelectedSection] = useState<string>('');
  const [kmSearch, setKmSearch] = useState('');
  const [secSearch, setSecSearch] = useState('');
  const [kmDropdownOpen, setKmDropdownOpen] = useState(false);
  const [secDropdownOpen, setSecDropdownOpen] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/key-measures').then((r: any) => r?.json?.()).then((d: any) => setKeyMeasures(d ?? [])).catch(() => {});
      fetch('/api/sections').then((r: any) => r?.json?.()).then((d: any) => setSections(d ?? [])).catch(() => {});
      setSelectedKM('');
      setSelectedSection('');
      setKmSearch('');
      setSecSearch('');
    }
  }, [isOpen]);

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;
    const handleClick = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    // Delay to avoid closing immediately from the triggering click
    const timer = setTimeout(() => {
      document.addEventListener('mousedown', handleClick);
    }, 10);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('mousedown', handleClick);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredKM = (keyMeasures ?? []).filter((km: KeyMeasureData) =>
    (km?.name ?? '').toLowerCase().includes((kmSearch ?? '').toLowerCase())
  );
  const filteredSec = (sections ?? []).filter((s: SectionData) =>
    (s?.name ?? '').toLowerCase().includes((secSearch ?? '').toLowerCase())
  );

  const selectedKMName = (keyMeasures ?? []).find((km: KeyMeasureData) => km?.id === selectedKM)?.name ?? '';
  const selectedSecName = (sections ?? []).find((s: SectionData) => s?.id === selectedSection)?.name ?? '';

  // Calculate popover position near the anchor button
  let popoverStyle: React.CSSProperties = {};
  if (anchorRect) {
    const popoverWidth = 320;
    // Position to the left of the anchor, vertically centered on the anchor
    let left = anchorRect.left - popoverWidth - 8;
    let top = anchorRect.top - 20;

    // Clamp to viewport
    if (left < 8) left = anchorRect.right + 8;
    if (top + 400 > window.innerHeight) top = window.innerHeight - 410;
    if (top < 8) top = 8;

    popoverStyle = {
      position: 'fixed',
      left: `${left}px`,
      top: `${top}px`,
      width: `${popoverWidth}px`,
    };
  } else {
    // Fallback: position at the right side of screen
    popoverStyle = {
      position: 'fixed',
      right: '356px',
      top: '50%',
      transform: 'translateY(-50%)',
      width: '320px',
    };
  }

  return (
    <div className="fixed inset-0 z-50">
      {/* Transparent backdrop */}
      <div className="absolute inset-0" />

      {/* Popover */}
      <div
        ref={popoverRef}
        className="bg-white rounded-lg shadow-xl border border-gray-200"
        style={popoverStyle}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
          <h2 className="text-sm font-semibold text-gray-800">Assign Measurement</h2>
          <button onClick={onClose} className="p-0.5 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-3.5 h-3.5 text-gray-500" />
          </button>
        </div>

        <div className="px-4 py-3 space-y-3">
          {/* Selected measurements info */}
          <div className="bg-gray-50 rounded-md px-2.5 py-1.5">
            <p className="text-[11px] text-gray-500">Assigning {(measurementNames ?? [])?.length ?? 0} measurement(s):</p>
            <p className="text-xs text-gray-700 mt-0.5 truncate">
              {(measurementNames ?? []).join(', ')}
            </p>
          </div>

          {/* Key Measure dropdown */}
          <div className="relative">
            <label className="block text-xs font-medium text-gray-700 mb-1">Key Measure *</label>
            <div
              className="border border-gray-300 rounded-md px-2.5 py-1.5 flex items-center gap-2 cursor-pointer hover:border-blue-400 transition-colors"
              onClick={() => { setKmDropdownOpen(!kmDropdownOpen); setSecDropdownOpen(false); }}
            >
              <Search className="w-3.5 h-3.5 text-gray-400" />
              {selectedKM ? (
                <span className="text-xs text-gray-800">{selectedKMName}</span>
              ) : (
                <input
                  type="text"
                  value={kmSearch}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => { setKmSearch(e?.target?.value ?? ''); setKmDropdownOpen(true); }}
                  onClick={(e: React.MouseEvent) => { e.stopPropagation(); setKmDropdownOpen(true); }}
                  placeholder="Search key measures..."
                  className="text-xs flex-1 outline-none bg-transparent"
                />
              )}
              {selectedKM && (
                <button onClick={(e: React.MouseEvent) => { e.stopPropagation(); setSelectedKM(''); }} className="ml-auto">
                  <X className="w-3 h-3 text-gray-400" />
                </button>
              )}
            </div>
            {kmDropdownOpen && (
              <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-[160px] overflow-y-auto">
                {(filteredKM ?? []).map((km: KeyMeasureData) => (
                  <button
                    key={km?.id}
                    onClick={() => { setSelectedKM(km?.id ?? ''); setKmDropdownOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 text-xs hover:bg-blue-50 flex items-center gap-2 transition-colors ${
                      selectedKM === km?.id ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                    }`}
                  >
                    {selectedKM === km?.id && <Check className="w-3 h-3 text-blue-500" />}
                    <div>
                      <div>{km?.name ?? ''}</div>
                      <div className="text-[10px] text-gray-400">{km?.category ?? ''}</div>
                    </div>
                  </button>
                ))}
                {(filteredKM ?? [])?.length === 0 && (
                  <div className="px-2.5 py-1.5 text-xs text-gray-400">No matches found</div>
                )}
              </div>
            )}
          </div>

          {/* Section dropdown */}
          <div className="relative">
            <label className="block text-xs font-medium text-gray-700 mb-1">Section (optional)</label>
            <div
              className="border border-gray-300 rounded-md px-2.5 py-1.5 flex items-center gap-2 cursor-pointer hover:border-blue-400 transition-colors"
              onClick={() => { setSecDropdownOpen(!secDropdownOpen); setKmDropdownOpen(false); }}
            >
              <Search className="w-3.5 h-3.5 text-gray-400" />
              {selectedSection ? (
                <span className="text-xs text-gray-800">{selectedSecName}</span>
              ) : (
                <input
                  type="text"
                  value={secSearch}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => { setSecSearch(e?.target?.value ?? ''); setSecDropdownOpen(true); }}
                  onClick={(e: React.MouseEvent) => { e.stopPropagation(); setSecDropdownOpen(true); }}
                  placeholder="Search sections..."
                  className="text-xs flex-1 outline-none bg-transparent"
                />
              )}
              {selectedSection && (
                <button onClick={(e: React.MouseEvent) => { e.stopPropagation(); setSelectedSection(''); }} className="ml-auto">
                  <X className="w-3 h-3 text-gray-400" />
                </button>
              )}
            </div>
            {secDropdownOpen && (
              <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-[160px] overflow-y-auto">
                {(filteredSec ?? []).map((s: SectionData) => (
                  <button
                    key={s?.id}
                    onClick={() => { setSelectedSection(s?.id ?? ''); setSecDropdownOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 text-xs hover:bg-blue-50 flex items-center gap-2 transition-colors ${
                      selectedSection === s?.id ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                    }`}
                  >
                    {selectedSection === s?.id && <Check className="w-3 h-3 text-blue-500" />}
                    <span>{s?.name ?? ''}</span>
                  </button>
                ))}
                {(filteredSec ?? [])?.length === 0 && (
                  <div className="px-2.5 py-1.5 text-xs text-gray-400">No matches found</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-4 py-2.5 border-t border-gray-200 bg-gray-50 rounded-b-lg">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              if (selectedKM) {
                onApply?.(selectedKM, selectedSection || null);
              }
            }}
            disabled={!selectedKM}
            className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
              selectedKM
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  );
}
