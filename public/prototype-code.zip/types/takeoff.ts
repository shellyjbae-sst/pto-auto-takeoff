export interface MarkupData {
  type: 'polygon' | 'line' | 'points';
  points: number[][];
}

export interface AssignmentData {
  id: string;
  measurementId: string;
  keyMeasureId: string;
  sectionId: string | null;
  useId: string | null;
  fromQuickMeasure: boolean;
  measurement: MeasurementData;
  keyMeasure: KeyMeasureData;
  section: SectionData | null;
  use: UseData | null;
  createdAt: string;
}

export interface MeasurementData {
  id: string;
  name: string;
  type: 'area' | 'linear' | 'count';
  color: string;
  value: number;
  unit: string;
  segmentCount: number;
  visible: boolean;
  isAI: boolean;
  groupId: string | null;
  sheetId: string | null;
  markupData: MarkupData;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
  assignments?: AssignmentData[];
}

export interface SheetData {
  id: string;
  name: string;
  category: string;
  scale: string;
  pageIndex: number;
  sortOrder: number;
}

export interface KeyMeasureData {
  id: string;
  name: string;
  color: string;
  category: string;
  sortOrder: number;
}

export interface SectionData {
  id: string;
  name: string;
  sortOrder: number;
}

export interface UseData {
  id: string;
  name: string;
  sortOrder: number;
}
