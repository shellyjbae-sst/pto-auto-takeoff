'use client';

import React, { useState, useCallback, useEffect } from 'react';
import { SheetData } from '@/types/takeoff';
import {
  X,
  Sparkles,
  Zap,
  Scale,
  Settings2,
  Play,
  ChevronRight,
  ChevronLeft,
  Check,
  Clock,
  Info,
  Layers,
  FileText,
  Save,
  Filter,
  Brain,
  Crosshair,
  Cpu,
  BoxSelect,
  Plus,
  Trash2,
  Bookmark,
  ChevronDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

/* ===== Types ===== */
export interface RegionBounds {
  x: number; y: number; w: number; h: number;
}

export interface AutoTakeoffConfig {
  // Scope
  scopeMode: 'all' | 'current' | 'selected' | 'region';
  selectedSheetIds: Set<string>;
  regionBounds: RegionBounds | null;
  // Model
  modelCategories: Set<string>;
  // Run mode
  runMode: 'fast' | 'balanced' | 'precision';
  // Granularity
  granularity: 'coarse' | 'standard' | 'detailed';
  // Pre-filters
  minAreaSqFt: number;
  excludeObjectTypes: Set<string>;
  // Preset
  presetName: string;
}

const DEFAULT_CONFIG: AutoTakeoffConfig = {
  scopeMode: 'current',
  selectedSheetIds: new Set(),
  regionBounds: null,
  modelCategories: new Set(['walls', 'structural', 'doors_windows', 'roof']),
  runMode: 'balanced',
  granularity: 'standard',
  minAreaSqFt: 0,
  excludeObjectTypes: new Set(),
  presetName: '',
};

interface AutoTakeoffModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRun: (config: AutoTakeoffConfig) => void;
  sheets: SheetData[];
  activeSheetId: string | null;
  onStartRegionSelect?: () => void;
  externalRegionBounds?: { x: number; y: number; w: number; h: number } | null;
}

const MODEL_CATEGORIES = [
  { id: 'walls', label: 'Walls', desc: 'Interior & exterior walls' },
  { id: 'structural', label: 'Structural', desc: 'Beams, columns, footings' },
  { id: 'doors_windows', label: 'Doors / Windows', desc: 'Openings & frames' },
  { id: 'roof', label: 'Roof', desc: 'Rafters, trusses, sheathing' },
  { id: 'electrical', label: 'Electrical', desc: 'Outlets, panels, conduit' },
  { id: 'plumbing', label: 'Plumbing', desc: 'Pipes, fixtures, drains' },
  { id: 'hvac', label: 'HVAC', desc: 'Ductwork, vents, units' },
  { id: 'finishes', label: 'Finishes', desc: 'Flooring, ceilings, trim' },
];

const OBJECT_TYPES_TO_EXCLUDE = [
  'furniture', 'electrical_fixtures', 'annotations', 'dimensions', 'text_labels', 'hatching',
];

const RUN_MODES = [
  { id: 'fast' as const, label: 'Fast', desc: 'Lower accuracy, fewer compute units', icon: Zap, time: '~2 min', cu: 2, color: 'text-amber-600 bg-amber-50 border-amber-200' },
  { id: 'balanced' as const, label: 'Balanced', desc: 'Good accuracy/speed tradeoff', icon: Scale, time: '~5 min', cu: 5, color: 'text-blue-600 bg-blue-50 border-blue-200' },
  { id: 'precision' as const, label: 'High Accuracy', desc: 'Best results, longer runtime', icon: Brain, time: '~12 min', cu: 12, color: 'text-purple-600 bg-purple-50 border-purple-200' },
];

const GRANULARITY_LEVELS = [
  { id: 'coarse' as const, label: 'Coarse', desc: 'Bulk counts & areas' },
  { id: 'standard' as const, label: 'Standard', desc: 'Individual elements' },
  { id: 'detailed' as const, label: 'Detailed', desc: 'Per-component attributes' },
];

interface SavedPreset {
  name: string;
  builtIn?: boolean;
  config: {
    scopeMode: AutoTakeoffConfig['scopeMode'];
    modelCategories: Set<string>;
    runMode: AutoTakeoffConfig['runMode'];
    granularity: AutoTakeoffConfig['granularity'];
    minAreaSqFt: number;
    excludeObjectTypes: Set<string>;
  };
}

const BUILT_IN_PRESETS: SavedPreset[] = [
  {
    name: 'Structural Review',
    builtIn: true,
    config: { scopeMode: 'current', modelCategories: new Set(['walls', 'structural']), runMode: 'precision', granularity: 'detailed', minAreaSqFt: 0, excludeObjectTypes: new Set(['furniture', 'annotations', 'text_labels']) },
  },
  {
    name: 'Quick Bid',
    builtIn: true,
    config: { scopeMode: 'all', modelCategories: new Set(['walls', 'doors_windows', 'roof']), runMode: 'fast', granularity: 'coarse', minAreaSqFt: 10, excludeObjectTypes: new Set(['furniture', 'hatching', 'annotations']) },
  },
  {
    name: 'Full Takeoff',
    builtIn: true,
    config: { scopeMode: 'all', modelCategories: new Set(['walls', 'structural', 'doors_windows', 'roof', 'electrical', 'plumbing', 'hvac', 'finishes']), runMode: 'balanced', granularity: 'standard', minAreaSqFt: 0, excludeObjectTypes: new Set() },
  },
];

const STEPS = ['Scope & Model', 'Run Settings', 'Review & Run'];

export default function AutoTakeoffModal({ isOpen, onClose, onRun, sheets, activeSheetId, onStartRegionSelect, externalRegionBounds }: AutoTakeoffModalProps) {
  const [step, setStep] = useState(0);
  const [config, setConfig] = useState<AutoTakeoffConfig>(() => ({
    ...DEFAULT_CONFIG,
    selectedSheetIds: new Set(activeSheetId ? [activeSheetId] : []),
  }));

  // When external region bounds arrive (drawn on canvas), apply them
  useEffect(() => {
    if (externalRegionBounds && isOpen) {
      setConfig((p) => ({ ...p, scopeMode: 'region', regionBounds: externalRegionBounds }));
    }
  }, [externalRegionBounds, isOpen]);

  const handleClose = useCallback(() => {
    setStep(0);
    onClose();
  }, [onClose]);

  const handleRun = useCallback(() => {
    onRun(config);
    setStep(0);
  }, [config, onRun]);

  const toggleModelCat = (id: string) => {
    setConfig((prev) => {
      const next = new Set(prev.modelCategories);
      if (next.has(id)) next.delete(id); else next.add(id);
      return { ...prev, modelCategories: next };
    });
  };

  const toggleSheet = (id: string) => {
    setConfig((prev) => {
      const next = new Set(prev.selectedSheetIds);
      if (next.has(id)) next.delete(id); else next.add(id);
      return { ...prev, selectedSheetIds: next };
    });
  };

  const [customPresets, setCustomPresets] = useState<SavedPreset[]>([]);

  const toggleExclude = (type: string) => {
    setConfig((prev) => {
      const next = new Set(prev.excludeObjectTypes);
      if (next.has(type)) next.delete(type); else next.add(type);
      return { ...prev, excludeObjectTypes: next };
    });
  };

  const applyPreset = (preset: SavedPreset) => {
    setConfig((prev) => ({
      ...prev,
      scopeMode: preset.config.scopeMode,
      modelCategories: new Set(preset.config.modelCategories),
      runMode: preset.config.runMode,
      granularity: preset.config.granularity,
      minAreaSqFt: preset.config.minAreaSqFt,
      excludeObjectTypes: new Set(preset.config.excludeObjectTypes),
      presetName: preset.name,
    }));
  };

  const saveAsPreset = (name: string) => {
    const newPreset: SavedPreset = {
      name,
      config: {
        scopeMode: config.scopeMode,
        modelCategories: new Set(config.modelCategories),
        runMode: config.runMode,
        granularity: config.granularity,
        minAreaSqFt: config.minAreaSqFt,
        excludeObjectTypes: new Set(config.excludeObjectTypes),
      },
    };
    setCustomPresets((prev) => [...prev.filter((p) => p.name !== name), newPreset]);
    setConfig((prev) => ({ ...prev, presetName: name }));
  };

  const deleteCustomPreset = (name: string) => {
    setCustomPresets((prev) => prev.filter((p) => p.name !== name));
    if (config.presetName === name) {
      setConfig((prev) => ({ ...prev, presetName: '' }));
    }
  };

  const allPresets = [...BUILT_IN_PRESETS, ...customPresets];

  const selectedRunMode = RUN_MODES.find((m) => m.id === config.runMode)!;

  // Compute estimate (simulated) — uses "Compute Units" (CU) instead of $$
  const sheetCount = config.scopeMode === 'all' ? sheets.length : config.scopeMode === 'region' ? 1 : config.scopeMode === 'current' ? 1 : config.selectedSheetIds.size;
  const regionDiscount = config.scopeMode === 'region' && config.regionBounds ? 0.4 : 1; // region is partial sheet, cheaper
  const modelCount = config.modelCategories.size;
  const timeMultiplier = config.runMode === 'fast' ? 1 : config.runMode === 'balanced' ? 2.5 : 6;
  const granMultiplier = config.granularity === 'coarse' ? 0.7 : config.granularity === 'standard' ? 1 : 1.5;
  const estMinutes = Math.max(1, Math.round(sheetCount * modelCount * 0.3 * timeMultiplier * granMultiplier * regionDiscount));
  const estCU = Math.max(1, Math.round(sheetCount * modelCount * selectedRunMode.cu * granMultiplier * regionDiscount * 0.5));

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />

      {/* Modal */}
      <div className="relative bg-white rounded-xl shadow-2xl w-[640px] max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-indigo-50">
          <div className="w-9 h-9 rounded-lg bg-purple-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-base font-semibold text-gray-900">Auto-Takeoff</h2>
            <p className="text-xs text-gray-500">Configure AI-assisted measurement detection</p>
          </div>
          <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-gray-200/60 transition-colors">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-0 px-6 py-3 border-b border-gray-100 bg-gray-50/50">
          {STEPS.map((label, i) => (
            <React.Fragment key={label}>
              <button
                onClick={() => setStep(i)}
                className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${
                  i === step ? 'text-purple-700' : i < step ? 'text-green-600' : 'text-gray-400'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border transition-colors ${
                  i === step ? 'bg-purple-600 text-white border-purple-600' : i < step ? 'bg-green-500 text-white border-green-500' : 'bg-white text-gray-400 border-gray-300'
                }`}>
                  {i < step ? <Check className="w-3 h-3" /> : i + 1}
                </div>
                <span className="hidden sm:inline">{label}</span>
              </button>
              {i < STEPS.length - 1 && (
                <div className={`flex-1 h-px mx-2 ${i < step ? 'bg-green-300' : 'bg-gray-200'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {step === 0 && <StepScopeModel config={config} setConfig={setConfig} sheets={sheets} activeSheetId={activeSheetId} toggleModelCat={toggleModelCat} toggleSheet={toggleSheet} onStartRegionSelect={onStartRegionSelect} allPresets={allPresets} applyPreset={applyPreset} saveAsPreset={saveAsPreset} deleteCustomPreset={deleteCustomPreset} toggleExclude={toggleExclude} />}
          {step === 1 && <StepRunSettings config={config} setConfig={setConfig} />}
          {step === 2 && <StepReview config={config} sheets={sheets} estMinutes={estMinutes} estCU={estCU} selectedRunMode={selectedRunMode} />}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-2 px-6 py-3 border-t border-gray-200 bg-gray-50/50">
          {step > 0 && (
            <Button variant="outline" size="sm" onClick={() => setStep(step - 1)} className="gap-1">
              <ChevronLeft className="w-3.5 h-3.5" /> Back
            </Button>
          )}
          <div className="flex-1" />
          <div className="flex items-center gap-1.5 text-xs text-gray-400 mr-2">
            <Clock className="w-3.5 h-3.5" />
            <span>~{estMinutes} min</span>
            <span className="mx-1">·</span>
            <Cpu className="w-3.5 h-3.5" />
            <span>{estCU} CU</span>
          </div>
          {step < STEPS.length - 1 ? (
            <Button size="sm" onClick={() => setStep(step + 1)} className="gap-1 bg-purple-600 hover:bg-purple-700">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          ) : (
            <Button size="sm" onClick={handleRun} className="gap-1.5 bg-purple-600 hover:bg-purple-700">
              <Play className="w-3.5 h-3.5" /> Run Auto-Takeoff
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ===== Step 1: Scope & Model ===== */
function StepScopeModel({ config, setConfig, sheets, activeSheetId, toggleModelCat, toggleSheet, onStartRegionSelect, allPresets, applyPreset, saveAsPreset, deleteCustomPreset, toggleExclude }: {
  config: AutoTakeoffConfig;
  setConfig: React.Dispatch<React.SetStateAction<AutoTakeoffConfig>>;
  sheets: SheetData[];
  activeSheetId: string | null;
  toggleModelCat: (id: string) => void;
  toggleSheet: (id: string) => void;
  onStartRegionSelect?: () => void;
  allPresets: SavedPreset[];
  applyPreset: (preset: SavedPreset) => void;
  saveAsPreset: (name: string) => void;
  deleteCustomPreset: (name: string) => void;
  toggleExclude: (type: string) => void;
}) {
  const activeSheet = sheets.find((s) => s.id === activeSheetId);
  const [presetOpen, setPresetOpen] = useState(false);
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const scopeLabels: Record<string, string> = { all: 'All Sheets', current: 'Current Sheet', selected: 'Selected Sheets', region: 'Region' };

  const handleSavePreset = () => {
    const trimmed = newPresetName.trim();
    if (!trimmed) return;
    saveAsPreset(trimmed);
    setNewPresetName('');
    setShowSaveForm(false);
  };

  return (
    <div className="space-y-5">
      {/* Preset Accordion */}
      <div className="rounded-lg border border-gray-200 overflow-hidden">
        <button
          onClick={() => setPresetOpen(!presetOpen)}
          className="w-full flex items-center gap-2 px-3 py-2.5 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
        >
          <Bookmark className="w-3.5 h-3.5 text-purple-500" />
          <span className="text-xs font-semibold text-gray-700 flex-1">
            {config.presetName ? `Preset: ${config.presetName}` : 'Load from Preset'}
          </span>
          {config.presetName && <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-100 text-purple-600 font-medium">Active</span>}
          <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform ${presetOpen ? 'rotate-180' : ''}`} />
        </button>
        {presetOpen && (
          <div className="px-3 py-2.5 border-t border-gray-100 space-y-1.5 bg-white">
            {allPresets.map((preset) => {
              const isActive = config.presetName === preset.name;
              const modelNames = MODEL_CATEGORIES.filter((c) => preset.config.modelCategories.has(c.id)).map((c) => c.label);
              const runModeInfo = RUN_MODES.find((m) => m.id === preset.config.runMode);
              const filterParts: string[] = [];
              if (preset.config.minAreaSqFt > 0) filterParts.push(`min ${preset.config.minAreaSqFt} sqft`);
              if (preset.config.excludeObjectTypes.size > 0) filterParts.push(`${preset.config.excludeObjectTypes.size} excluded`);
              return (
                <div
                  key={preset.name}
                  onClick={() => { applyPreset(preset); setPresetOpen(false); }}
                  className={`flex items-start gap-2 px-2.5 py-2 rounded-md cursor-pointer transition-all ${
                    isActive ? 'bg-purple-50 ring-1 ring-purple-200' : 'hover:bg-gray-50'
                  }`}
                >
                  <Bookmark className={`w-3 h-3 mt-0.5 flex-shrink-0 ${isActive ? 'text-purple-600 fill-purple-600' : 'text-gray-400'}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-xs font-semibold ${isActive ? 'text-purple-700' : 'text-gray-700'}`}>{preset.name}</span>
                      {preset.builtIn && <span className="text-[8px] px-1 py-px rounded bg-gray-100 text-gray-400 font-medium uppercase">Built-in</span>}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">
                      {scopeLabels[preset.config.scopeMode]} · {modelNames.length <= 2 ? modelNames.join(', ') : `${modelNames.length} models`} · {runModeInfo?.label ?? preset.config.runMode} · {preset.config.granularity}{filterParts.length > 0 ? ` · ${filterParts.join(', ')}` : ''}
                    </p>
                  </div>
                  {!preset.builtIn && (
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteCustomPreset(preset.name); }}
                      className="p-0.5 rounded hover:bg-red-100 transition-colors mt-0.5"
                    >
                      <Trash2 className="w-3 h-3 text-gray-400 hover:text-red-500" />
                    </button>
                  )}
                  {isActive && <Check className="w-3.5 h-3.5 text-purple-600 flex-shrink-0 mt-0.5" />}
                </div>
              );
            })}
            {/* Save as preset */}
            <div className="pt-1 border-t border-gray-100 mt-1">
              {!showSaveForm ? (
                <button
                  onClick={() => setShowSaveForm(true)}
                  className="flex items-center gap-1 text-[11px] text-purple-600 hover:text-purple-700 font-medium py-1"
                >
                  <Plus className="w-3 h-3" /> Save current settings as preset
                </button>
              ) : (
                <div className="flex items-center gap-1.5 py-1">
                  <Input
                    autoFocus
                    placeholder="Preset name…"
                    value={newPresetName}
                    onChange={(e) => setNewPresetName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleSavePreset(); if (e.key === 'Escape') setShowSaveForm(false); }}
                    className="h-6 text-[11px] flex-1"
                  />
                  <Button size="sm" onClick={handleSavePreset} disabled={!newPresetName.trim()} className="h-6 px-2 text-[11px] bg-purple-600 hover:bg-purple-700">
                    Save
                  </Button>
                  <button onClick={() => setShowSaveForm(false)} className="p-0.5 rounded hover:bg-gray-200">
                    <X className="w-3 h-3 text-gray-400" />
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Scope Selection */}
      <div>
        <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-gray-500" /> Input Scope
        </h4>
        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'all' as const, label: 'All Sheets', desc: `${sheets.length} sheets`, icon: Layers },
            { id: 'current' as const, label: 'Current Sheet', desc: activeSheet?.name ?? 'None', icon: FileText },
            { id: 'selected' as const, label: 'Select Sheets', desc: 'Choose specific', icon: Check },
            { id: 'region' as const, label: 'Selected Region', desc: config.regionBounds ? 'Region selected ✓' : 'Draw area on sheet', icon: BoxSelect },
          ].map((opt) => {
            const Icon = opt.icon;
            return (
              <button
                key={opt.id}
                onClick={() => {
                  if (opt.id === 'region' && onStartRegionSelect) {
                    // Set scope mode and trigger draw-on-plan flow
                    setConfig((p) => ({ ...p, scopeMode: 'region' }));
                    onStartRegionSelect();
                  } else {
                    setConfig((p) => ({ ...p, scopeMode: opt.id }));
                  }
                }}
                className={`p-3 rounded-lg border text-left transition-all flex items-start gap-2.5 ${
                  config.scopeMode === opt.id
                    ? 'border-purple-400 bg-purple-50 ring-1 ring-purple-200'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <Icon className={`w-4 h-4 flex-shrink-0 mt-0.5 ${config.scopeMode === opt.id ? 'text-purple-600' : 'text-gray-400'}`} />
                <div>
                  <span className={`text-xs font-semibold ${config.scopeMode === opt.id ? 'text-purple-700' : 'text-gray-700'}`}>
                    {opt.label}
                  </span>
                  <p className="text-[10px] text-gray-500 mt-0.5">{opt.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Sheet picker when 'selected' */}
        {config.scopeMode === 'selected' && (
          <div className="mt-2 max-h-32 overflow-y-auto border border-gray-200 rounded-lg p-2 space-y-0.5">
            {sheets.map((s) => (
              <label key={s.id} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.selectedSheetIds.has(s.id)}
                  onChange={() => toggleSheet(s.id)}
                  className="w-3.5 h-3.5 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-xs text-gray-700">{s.name}</span>
              </label>
            ))}
          </div>
        )}

        {/* Region info when 'region' */}
        {config.scopeMode === 'region' && (
          <div className="mt-2 border border-purple-200 bg-purple-50/50 rounded-lg p-3">
            {config.regionBounds ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-purple-100 flex items-center justify-center">
                    <Crosshair className="w-3.5 h-3.5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-purple-800">Region selected</p>
                    <p className="text-[10px] text-purple-600">{config.regionBounds.w} × {config.regionBounds.h} px on current sheet</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onStartRegionSelect?.()}
                    className="text-[10px] font-medium text-purple-600 hover:text-purple-800 bg-purple-100 hover:bg-purple-200 px-2 py-1 rounded transition-colors"
                  >
                    Redraw
                  </button>
                  <button
                    onClick={() => setConfig((p) => ({ ...p, regionBounds: null }))}
                    className="text-[10px] font-medium text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded transition-colors"
                  >
                    Clear
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => onStartRegionSelect?.()}
                className="w-full flex items-center justify-center gap-2 py-3 text-xs font-semibold text-purple-700 hover:text-purple-900 hover:bg-purple-100 rounded-md transition-colors"
              >
                <Crosshair className="w-4 h-4" />
                Draw Region on Plan
              </button>
            )}
          </div>
        )}
      </div>

      {/* Model Categories */}
      <div>
        <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-gray-500" /> What to Detect
        </h4>
        <div className="grid grid-cols-2 gap-1.5">
          {MODEL_CATEGORIES.map((cat) => {
            const selected = config.modelCategories.has(cat.id);
            return (
              <button
                key={cat.id}
                onClick={() => toggleModelCat(cat.id)}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border text-left transition-all ${
                  selected
                    ? 'border-purple-300 bg-purple-50/70'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 transition-colors ${
                  selected ? 'bg-purple-600 border-purple-600' : 'border-gray-300'
                }`}>
                  {selected && <Check className="w-3 h-3 text-white" />}
                </div>
                <div className="min-w-0">
                  <span className={`text-xs font-medium ${selected ? 'text-purple-700' : 'text-gray-700'}`}>{cat.label}</span>
                  <p className="text-[10px] text-gray-400 truncate">{cat.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
        <div className="flex gap-2 mt-2">
          <button
            onClick={() => setConfig((p) => ({ ...p, modelCategories: new Set(MODEL_CATEGORIES.map((c) => c.id)) }))}
            className="text-[10px] text-purple-600 hover:text-purple-800 font-medium"
          >
            Select All
          </button>
          <button
            onClick={() => setConfig((p) => ({ ...p, modelCategories: new Set() }))}
            className="text-[10px] text-gray-500 hover:text-gray-700 font-medium"
          >
            Clear
          </button>
        </div>
      </div>

      {/* Pre-filters */}
      <div>
        <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-1.5">
          <Filter className="w-4 h-4 text-gray-500" /> Pre-filters
        </h4>

        {/* Min area */}
        <div className="flex items-center gap-3 mb-3">
          <label className="text-xs text-gray-600 w-40 flex-shrink-0">Ignore features under</label>
          <div className="flex items-center gap-1">
            <Input
              type="number"
              min={0}
              value={config.minAreaSqFt}
              onChange={(e) => setConfig((p) => ({ ...p, minAreaSqFt: Number(e.target.value) || 0 }))}
              className="h-8 w-20 text-xs"
            />
            <span className="text-xs text-gray-500">sq ft</span>
          </div>
        </div>

        {/* Exclude object types */}
        <div>
          <p className="text-xs text-gray-500 mb-2">Exclude object types:</p>
          <div className="flex flex-wrap gap-1.5">
            {OBJECT_TYPES_TO_EXCLUDE.map((type) => {
              const excluded = config.excludeObjectTypes.has(type);
              const label = type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
              return (
                <button
                  key={type}
                  onClick={() => toggleExclude(type)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-medium border transition-all ${
                    excluded
                      ? 'bg-red-50 border-red-200 text-red-700 line-through'
                      : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===== Step 2: Run Settings ===== */
function StepRunSettings({ config, setConfig }: {
  config: AutoTakeoffConfig;
  setConfig: React.Dispatch<React.SetStateAction<AutoTakeoffConfig>>;
}) {
  return (
    <div className="space-y-5">
      {/* Run Mode */}
      <div>
        <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-1.5">
          <Zap className="w-4 h-4 text-gray-500" /> Run Mode
        </h4>
        <div className="space-y-2">
          {RUN_MODES.map((mode) => {
            const Icon = mode.icon;
            const selected = config.runMode === mode.id;
            return (
              <button
                key={mode.id}
                onClick={() => setConfig((p) => ({ ...p, runMode: mode.id }))}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg border text-left transition-all ${
                  selected
                    ? `${mode.color} ring-1 ring-current/20`
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  selected ? 'bg-current/10' : 'bg-gray-100'
                }`}>
                  <Icon className={`w-4.5 h-4.5 ${selected ? '' : 'text-gray-500'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <span className={`text-sm font-semibold ${selected ? '' : 'text-gray-700'}`}>{mode.label}</span>
                  <p className={`text-xs ${selected ? 'opacity-70' : 'text-gray-400'}`}>{mode.desc}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className={`text-xs font-mono ${selected ? '' : 'text-gray-500'}`}>{mode.time}</div>
                  <div className={`text-[10px] ${selected ? 'opacity-60' : 'text-gray-400'}`}>{mode.cu} CU / sheet</div>
                </div>
                {selected && (
                  <div className="w-5 h-5 rounded-full bg-current/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Granularity */}
      <div>
        <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-1.5">
          <Settings2 className="w-4 h-4 text-gray-500" /> Detail Level
        </h4>
        <div className="grid grid-cols-3 gap-2">
          {GRANULARITY_LEVELS.map((g) => {
            const selected = config.granularity === g.id;
            return (
              <button
                key={g.id}
                onClick={() => setConfig((p) => ({ ...p, granularity: g.id }))}
                className={`p-3 rounded-lg border text-center transition-all ${
                  selected
                    ? 'border-purple-400 bg-purple-50 ring-1 ring-purple-200'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <span className={`text-xs font-semibold block ${selected ? 'text-purple-700' : 'text-gray-700'}`}>{g.label}</span>
                <p className="text-[10px] text-gray-400 mt-0.5">{g.desc}</p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}


/* ===== Step 4: Review & Run ===== */
function StepReview({ config, sheets, estMinutes, estCU, selectedRunMode }: {
  config: AutoTakeoffConfig;
  sheets: SheetData[];
  estMinutes: number;
  estCU: number;
  selectedRunMode: typeof RUN_MODES[0];
}) {
  const scopeLabel = config.scopeMode === 'all'
    ? `All Sheets (${sheets.length})`
    : config.scopeMode === 'current'
    ? 'Current Sheet Only'
    : config.scopeMode === 'region'
    ? `Selected Region${config.regionBounds ? ` (${Math.round(config.regionBounds.w)}×${Math.round(config.regionBounds.h)} px)` : ''}`
    : `${config.selectedSheetIds.size} Selected Sheet(s)`;

  const modelLabels = MODEL_CATEGORIES.filter((c) => config.modelCategories.has(c.id)).map((c) => c.label);
  const granLabel = GRANULARITY_LEVELS.find((g) => g.id === config.granularity)?.label ?? '';
  const excludeLabels = [...config.excludeObjectTypes].map((t) => t.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()));

  // CU tier label
  const cuTier = estCU <= 5 ? 'Low' : estCU <= 15 ? 'Medium' : 'High';
  const cuTierColor = estCU <= 5 ? 'text-green-600' : estCU <= 15 ? 'text-amber-600' : 'text-red-600';

  return (
    <div className="space-y-4">
      <div className="p-4 bg-purple-50/60 rounded-lg border border-purple-200">
        <h4 className="text-sm font-semibold text-purple-800 mb-3">Run Summary</h4>
        <div className="space-y-2.5 text-xs">
          <SummaryRow label="Scope" value={scopeLabel} />
          <SummaryRow label="Detection Models" value={modelLabels.join(', ') || 'None selected'} />
          <SummaryRow label="Run Mode" value={`${selectedRunMode.label} — ${selectedRunMode.desc}`} />
          <SummaryRow label="Detail Level" value={granLabel} />
          {config.minAreaSqFt > 0 && <SummaryRow label="Min Area" value={`${config.minAreaSqFt} sq ft`} />}
          {excludeLabels.length > 0 && <SummaryRow label="Excluding" value={excludeLabels.join(', ')} />}
          {config.presetName && <SummaryRow label="Preset" value={config.presetName} />}
        </div>
      </div>

      {/* Estimate box */}
      <div className="flex gap-3">
        <div className="flex-1 p-3 bg-blue-50 rounded-lg border border-blue-200 text-center">
          <Clock className="w-5 h-5 text-blue-600 mx-auto mb-1" />
          <div className="text-lg font-bold text-blue-800">~{estMinutes} min</div>
          <p className="text-[10px] text-blue-500">Estimated runtime</p>
        </div>
        <div className="flex-1 p-3 bg-purple-50 rounded-lg border border-purple-200 text-center">
          <Cpu className="w-5 h-5 text-purple-600 mx-auto mb-1" />
          <div className="text-lg font-bold text-purple-800">{estCU} CU</div>
          <p className="text-[10px] text-purple-500">Compute Units</p>
        </div>
        <div className="flex-1 p-3 bg-gray-50 rounded-lg border border-gray-200 text-center">
          <Zap className="w-5 h-5 text-gray-500 mx-auto mb-1" />
          <div className={`text-lg font-bold ${cuTierColor}`}>{cuTier}</div>
          <p className="text-[10px] text-gray-400">Resource usage</p>
        </div>
      </div>

      <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-lg border border-amber-200">
        <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-700">
          AI detections will appear as Quick Measures with confidence scores. You can review, accept, edit, or reject each one in the Human-in-the-Loop review queue.
        </p>
      </div>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex">
      <span className="text-gray-500 w-32 flex-shrink-0">{label}</span>
      <span className="text-purple-800 font-medium">{value}</span>
    </div>
  );
}