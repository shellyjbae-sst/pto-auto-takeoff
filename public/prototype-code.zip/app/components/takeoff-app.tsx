'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MeasurementData, SheetData, AssignmentData, SectionData, UseData, KeyMeasureData } from '@/types/takeoff';
import LeftPanel from './left-panel';
import RightPanel from './right-panel';
import CanvasPanel from './canvas-panel';
import AssignModal from './assign-modal';
import NewMeasurementModal from './new-measurement-modal';
import AutoTakeoffModal, { AutoTakeoffConfig } from './auto-takeoff-modal';
import PlanImportModal, { DetectedSheet } from './plan-import-modal';
import ScaleDetectModal from './scale-detect-modal';
import { CanvasFilters, hasActiveFilters } from './canvas-filter-bar';
import { toast } from 'sonner';

export default function TakeoffApp() {
  const [measurements, setMeasurements] = useState<MeasurementData[]>([]);
  const [sheets, setSheets] = useState<SheetData[]>([]);
  const [assignments, setAssignments] = useState<AssignmentData[]>([]);
  const [keyMeasures, setKeyMeasures] = useState<KeyMeasureData[]>([]);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [assignTargetIds, setAssignTargetIds] = useState<string[]>([]);
  const [assignAnchorRect, setAssignAnchorRect] = useState<DOMRect | null>(null);
  const [newModalOpen, setNewModalOpen] = useState(false);
  const [sections, setSections] = useState<SectionData[]>([]);
  const [uses, setUses] = useState<UseData[]>([]);
  const [loading, setLoading] = useState(true);
  // Active Key Measure (selected from right panel for drawing)
  const [activeKeyMeasureId, setActiveKeyMeasureId] = useState<string | null>(null);
  // Active Sheet (selected/highlighted in left panel)
  const [activeSheetId, setActiveSheetId] = useState<string | null>(null);
  // Quick Measure Mode
  const [quickMeasureMode, setQuickMeasureMode] = useState(false);

  // Plan Import modal
  const [planImportOpen, setPlanImportOpen] = useState(false);

  // Scale Detect modal
  const [scaleDetectSheet, setScaleDetectSheet] = useState<SheetData | null>(null);

  // Auto-Takeoff modal
  const [autoTakeoffOpen, setAutoTakeoffOpen] = useState(false);
  const [autoTakeoffRunning, setAutoTakeoffRunning] = useState(false);
  // Region selection: modal hides, user draws on canvas, then modal returns
  const [regionSelectMode, setRegionSelectMode] = useState(false);
  const [pendingRegionBounds, setPendingRegionBounds] = useState<{ x: number; y: number; w: number; h: number } | null>(null);

  // Canvas markup filters
  const [canvasFilters, setCanvasFilters] = useState<CanvasFilters>({
    showKeyMeasures: true,
    showQuickMeasures: true,
    showAutoTakeoff: true,
    types: new Set(),
    sectionIds: new Set(),
    useIds: new Set(),
  });

  // Fetch data
  const fetchData = useCallback(async () => {
    try {
      const [measRes, sheetsRes, assignRes, secRes, useRes, kmRes] = await Promise.all([
        fetch('/api/measurements'),
        fetch('/api/sheets'),
        fetch('/api/assignments'),
        fetch('/api/sections'),
        fetch('/api/uses'),
        fetch('/api/key-measures'),
      ]);
      const measData = await measRes?.json?.().catch(() => []);
      const sheetsData = await sheetsRes?.json?.().catch(() => []);
      const assignData = await assignRes?.json?.().catch(() => []);
      const secData = await secRes?.json?.().catch(() => []);
      const useData = await useRes?.json?.().catch(() => []);
      const kmData = await kmRes?.json?.().catch(() => []);
      setMeasurements(Array.isArray(measData) ? measData : []);
      setSheets(Array.isArray(sheetsData) ? sheetsData : []);
      setAssignments(Array.isArray(assignData) ? assignData : []);
      setSections(Array.isArray(secData) ? secData : []);
      setUses(Array.isArray(useData) ? useData : []);
      setKeyMeasures(Array.isArray(kmData) ? kmData : []);
      // Auto-select first sheet if none selected
      if (!activeSheetId && Array.isArray(sheetsData) && sheetsData.length > 0) {
        setActiveSheetId(sheetsData[0].id);
      }
    } catch (e: any) {
      console.error('Failed to fetch data:', e);
    } finally {
      setLoading(false);
    }
  }, [activeSheetId]);

  useEffect(() => {
    fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Toggle visibility
  const handleToggleVisibility = useCallback(async (id: string) => {
    const m = (measurements ?? []).find((item: MeasurementData) => item?.id === id);
    if (!m) return;
    const newVisible = !m.visible;
    setMeasurements((prev: MeasurementData[]) =>
      (prev ?? []).map((item: MeasurementData) =>
        item?.id === id ? { ...(item ?? {}), visible: newVisible } : item
      )
    );
    try {
      await fetch(`/api/measurements/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ visible: newVisible }),
      });
    } catch (e: any) {
      console.error('Toggle visibility error:', e);
    }
  }, [measurements]);

  // Toggle selection
  const handleToggleSelect = useCallback((id: string) => {
    setSelectedIds((prev: Set<string>) => {
      const next = new Set(prev ?? []);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    setSelectedIds(new Set((measurements ?? []).map((m: MeasurementData) => m?.id ?? '')));
  }, [measurements]);

  const handleDeselectAll = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  // Open assign modal
  const handleAssign = useCallback((ids: string[], anchorRect?: DOMRect) => {
    setAssignTargetIds(ids ?? []);
    setAssignAnchorRect(anchorRect ?? null);
    setAssignModalOpen(true);
  }, []);

  // Apply assignment
  const handleApplyAssignment = useCallback(async (keyMeasureId: string, sectionId: string | null) => {
    try {
      await fetch('/api/assignments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          measurementIds: assignTargetIds,
          keyMeasureId,
          sectionId,
        }),
      });
      toast?.success?.('Measurements assigned successfully');
      setAssignModalOpen(false);
      setAssignTargetIds([]);
      setSelectedIds(new Set());
      fetchData();
    } catch (e: any) {
      console.error('Assignment error:', e);
      toast?.error?.('Failed to assign measurements');
    }
  }, [assignTargetIds, fetchData]);

  // Delete measurements
  const handleDelete = useCallback(async (ids: string[]) => {
    if (!(ids ?? [])?.length) return;
    try {
      await fetch('/api/measurements/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids, action: 'delete' }),
      });
      toast?.success?.(`${(ids ?? [])?.length ?? 0} measurement(s) deleted`);
      setSelectedIds(new Set());
      fetchData();
    } catch (e: any) {
      console.error('Delete error:', e);
      toast?.error?.('Failed to delete measurements');
    }
  }, [fetchData]);

  // Duplicate
  const handleDuplicate = useCallback(async (id: string) => {
    try {
      await fetch('/api/measurements/duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      toast?.success?.('Measurement duplicated');
      fetchData();
    } catch (e: any) {
      console.error('Duplicate error:', e);
      toast?.error?.('Failed to duplicate measurement');
    }
  }, [fetchData]);

  // Rename
  const handleRename = useCallback(async (id: string, name: string) => {
    setMeasurements((prev: MeasurementData[]) =>
      (prev ?? []).map((item: MeasurementData) =>
        item?.id === id ? { ...(item ?? {}), name } : item
      )
    );
    try {
      await fetch(`/api/measurements/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
    } catch (e: any) {
      console.error('Rename error:', e);
    }
  }, []);

  // Create new measurement
  const handleCreateMeasurement = useCallback(async (data: { name: string; type: string; color: string; value: number; unit: string }) => {
    try {
      const markupData = data?.type === 'area'
        ? { type: 'polygon', points: [[150, 150], [250, 150], [250, 250], [150, 250]] }
        : data?.type === 'linear'
        ? { type: 'line', points: [[150, 200], [350, 200]] }
        : { type: 'points', points: [[200, 200], [250, 250], [300, 200]] };
      await fetch('/api/measurements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          sheetId: activeSheetId,
          segmentCount: data?.type === 'count' ? Math.round(data?.value ?? 0) || 1 : 1,
          markupData,
        }),
      });
      toast?.success?.('Measurement created');
      setNewModalOpen(false);
      fetchData();
    } catch (e: any) {
      console.error('Create error:', e);
      toast?.error?.('Failed to create measurement');
    }
  }, [fetchData, activeSheetId]);

  // Handle Auto-Takeoff run (simulated for prototype)
  const handleAutoTakeoffRun = useCallback(async (config: AutoTakeoffConfig) => {
    setAutoTakeoffOpen(false);
    setAutoTakeoffRunning(true);
    toast?.info?.('Auto-Takeoff started — detecting measurements...', { duration: 3000 });

    // Simulate a processing delay then generate AI measurements
    setTimeout(async () => {
      try {
        const aiColors = ['#8B5CF6', '#A855F7', '#7C3AED', '#6D28D9', '#9333EA'];
        const typeOptions: ('area' | 'linear' | 'count')[] = ['area', 'linear', 'count'];
        const modelLabels = [...config.modelCategories];
        const sheetId = activeSheetId;

        // Generate 3-6 simulated detections
        const detectionCount = 3 + Math.floor(Math.random() * 4);
        const names = [
          'Wall Segment A', 'Door Opening 1', 'Window Frame W1', 'Roof Truss T1',
          'Floor Area FA-1', 'Column C1', 'Beam B1', 'Stair Run S1',
          'HVAC Duct D1', 'Pipe Run P1',
        ];

        for (let i = 0; i < detectionCount; i++) {
          const type = typeOptions[i % typeOptions.length];
          const color = aiColors[i % aiColors.length];
          const markupData = type === 'area'
            ? { type: 'polygon' as const, points: randomPolygon() }
            : type === 'linear'
            ? { type: 'line' as const, points: randomLine() }
            : { type: 'points' as const, points: randomPoints() };
          const value = type === 'count'
            ? Math.floor(Math.random() * 8) + 2
            : type === 'area'
            ? Math.round((Math.random() * 500 + 100) * 100) / 100
            : Math.round((Math.random() * 80 + 10) * 100) / 100;
          const unit = type === 'count' ? 'ea' : type === 'area' ? 'sf' : 'lf';
          const name = `AI: ${names[i % names.length]}`;

          await fetch('/api/measurements', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name,
              type,
              color,
              value,
              unit,
              sheetId,
              segmentCount: type === 'count' ? value : 1,
              isAI: true,
              markupData,
            }),
          });
        }

        toast?.success?.(`Auto-Takeoff complete — ${detectionCount} detections found`, { duration: 5000 });
        fetchData();
      } catch (e: any) {
        console.error('Auto-Takeoff error:', e);
        toast?.error?.('Auto-Takeoff failed');
      } finally {
        setAutoTakeoffRunning(false);
      }
    }, 2500);
  }, [activeSheetId, fetchData]);

  // Handle Plan Import completion
  const handlePlanImportComplete = useCallback(async (detectedSheets: DetectedSheet[]) => {
    setPlanImportOpen(false);
    try {
      const res = await fetch('/api/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sheets: detectedSheets.map((s, i) => ({
            name: s.name,
            category: s.category,
            scale: s.scale,
            pageIndex: s.pageIndex,
            sortOrder: (sheets?.length ?? 0) + i,
          })),
        }),
      });
      if (!res.ok) throw new Error('Failed to create sheets');
      const created = await res.json();
      toast?.success?.(`Imported ${created.length} sheets from plan`);
      await fetchData();
      // Select the first imported sheet
      if (created.length > 0) {
        setActiveSheetId(created[0].id);
      }
    } catch (e: any) {
      console.error('Plan import error:', e);
      toast?.error?.('Failed to import plan sheets');
    }
  }, [sheets, fetchData]);

  // Handle scale update from ScaleDetectModal
  const handleScaleUpdate = useCallback(async (sheetId: string, scale: string) => {
    try {
      const res = await fetch('/api/sheets', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updates: [{ id: sheetId, scale }] }),
      });
      if (!res.ok) throw new Error('Failed to update scale');
      toast?.success?.('Scale updated successfully');
      await fetchData();
    } catch (e: any) {
      console.error('Scale update error:', e);
      toast?.error?.('Failed to update scale');
    }
  }, [fetchData]);

  const assignTargetNames = (assignTargetIds ?? []).map((id: string) =>
    (measurements ?? []).find((m: MeasurementData) => m?.id === id)?.name ?? 'Unknown'
  );

  // Build a map: measurementId -> assignment[] for filter logic
  const assignmentsByMeasId = React.useMemo(() => {
    const map = new Map<string, AssignmentData[]>();
    for (const a of assignments) {
      const list = map.get(a.measurementId) || [];
      list.push(a);
      map.set(a.measurementId, list);
    }
    return map;
  }, [assignments]);

  // Compute canvas-filtered measurements
  const filteredMeasurements = React.useMemo(() => {
    if (!hasActiveFilters(canvasFilters)) return measurements;

    return measurements.map((m) => {
      let pass = true;
      const measAssigns = assignmentsByMeasId.get(m.id) || [];

      const isKeyMeasure = measAssigns.some((a) => !a.fromQuickMeasure);
      const isQuickMeasure = !isKeyMeasure;
      if (!canvasFilters.showKeyMeasures && isKeyMeasure) pass = false;
      if (!canvasFilters.showQuickMeasures && isQuickMeasure) pass = false;
      if (!canvasFilters.showAutoTakeoff && m.isAI) pass = false;

      if (canvasFilters.types.size > 0) {
        pass = pass && canvasFilters.types.has(m.type);
      }
      if (canvasFilters.sectionIds.size > 0) {
        pass = pass && measAssigns.some((a) => a.sectionId && canvasFilters.sectionIds.has(a.sectionId));
      }
      if (canvasFilters.useIds.size > 0) {
        pass = pass && measAssigns.some((a) => a.useId && canvasFilters.useIds.has(a.useId));
      }

      if (!pass) return { ...m, visible: false };
      return m;
    });
  }, [measurements, canvasFilters, assignmentsByMeasId]);

  const filteredVisibleCount = filteredMeasurements.filter((m) => m.visible).length;
  const totalVisibleCount = measurements.filter((m) => m.visible).length;

  const canvasHiddenIds = React.useMemo(() => {
    if (!hasActiveFilters(canvasFilters)) return new Set<string>();
    const hidden = new Set<string>();
    filteredMeasurements.forEach((m) => {
      const orig = measurements.find((o) => o.id === m.id);
      if (orig?.visible && !m.visible) hidden.add(m.id);
    });
    return hidden;
  }, [filteredMeasurements, measurements, canvasFilters]);

  const keyMeasureIds = React.useMemo(() => {
    const ids = new Set<string>();
    for (const [measId, assigns] of assignmentsByMeasId) {
      if (assigns.some((a) => !a.fromQuickMeasure)) ids.add(measId);
    }
    return ids;
  }, [assignmentsByMeasId]);

  const aiMeasurementIds = React.useMemo(() => {
    return new Set(measurements.filter((m) => m.isAI).map((m) => m.id));
  }, [measurements]);

  const sectionMeasurementCounts = React.useMemo(() => {
    const counts = new Map<string, number>();
    for (const [, assigns] of assignmentsByMeasId) {
      for (const a of assigns) {
        if (a.sectionId) counts.set(a.sectionId, (counts.get(a.sectionId) || 0) + 1);
      }
    }
    return counts;
  }, [assignmentsByMeasId]);

  const useMeasurementCounts = React.useMemo(() => {
    const counts = new Map<string, number>();
    for (const [, assigns] of assignmentsByMeasId) {
      for (const a of assigns) {
        if (a.useId) counts.set(a.useId, (counts.get(a.useId) || 0) + 1);
      }
    }
    return counts;
  }, [assignmentsByMeasId]);

  // Get active KM info for status bar display
  const activeKM = activeKeyMeasureId ? keyMeasures.find((km) => km.id === activeKeyMeasureId) : null;

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-gray-500">Loading takeoff data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-100 overflow-hidden">
      {/* Top Bar */}
      <div className="h-10 bg-[#1e293b] flex items-center px-4 gap-3 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 bg-blue-500 rounded flex items-center justify-center">
            <span className="text-[10px] font-bold text-white">TO</span>
          </div>
          <span className="text-sm font-semibold text-white">2D Takeoff</span>
        </div>
        <div className="w-px h-5 bg-gray-600" />
        <span className="text-xs text-gray-400">A-101 Ground Floor Plan</span>
        <div className="flex-1" />
        <span className="text-xs text-gray-500">Commercial Office Building - Phase 1</span>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        <LeftPanel
          sheets={sheets}
          measurements={measurements}
          assignments={assignments}
          keyMeasures={keyMeasures}
          activeSheetId={activeSheetId}
          onSelectSheet={setActiveSheetId}
          hoveredId={hoveredId}
          onHover={setHoveredId}
          onToggleVisibility={handleToggleVisibility}
          onImportPlan={() => setPlanImportOpen(true)}
          onDetectScale={(sheet) => setScaleDetectSheet(sheet)}
        />
        <CanvasPanel
          measurements={filteredMeasurements}
          hoveredId={hoveredId}
          canvasFilters={canvasFilters}
          onFiltersChange={setCanvasFilters}
          sections={sections}
          uses={uses}
          filteredVisibleCount={filteredVisibleCount}
          totalVisibleCount={totalVisibleCount}
          allMeasurements={measurements}
          keyMeasureIds={keyMeasureIds}
          aiMeasurementIds={aiMeasurementIds}
          sectionMeasurementCounts={sectionMeasurementCounts}
          useMeasurementCounts={useMeasurementCounts}
          quickMeasureMode={quickMeasureMode}
          onToggleQuickMeasureMode={() => setQuickMeasureMode(!quickMeasureMode)}
          activeKMName={activeKM?.name ?? null}
          activeScale={sheets.find(s => s.id === activeSheetId)?.scale ?? '1/4" = 1\''}
          onAutoTakeoffClick={() => setAutoTakeoffOpen(true)}
          regionSelectMode={regionSelectMode}
          onRegionDrawn={(bounds) => {
            setPendingRegionBounds(bounds);
            setRegionSelectMode(false);
            setAutoTakeoffOpen(true); // reopen modal
          }}
          onRegionCancel={() => {
            setRegionSelectMode(false);
            setAutoTakeoffOpen(true); // reopen modal without region
          }}
        />
        <RightPanel
          keyMeasures={keyMeasures}
          activeKeyMeasureId={activeKeyMeasureId}
          onSelectKeyMeasure={setActiveKeyMeasureId}
          measurements={measurements}
          assignments={assignments}
          hoveredId={hoveredId}
          selectedIds={selectedIds}
          onHover={setHoveredId}
          onToggleVisibility={handleToggleVisibility}
          onToggleSelect={handleToggleSelect}
          onSelectAll={handleSelectAll}
          onDeselectAll={handleDeselectAll}
          onAssign={handleAssign}
          onDelete={handleDelete}
          onDuplicate={handleDuplicate}
          onRename={handleRename}
          onNewClick={() => setNewModalOpen(true)}
        />
      </div>

      {/* Assign Modal */}
      <AssignModal
        isOpen={assignModalOpen}
        onClose={() => { setAssignModalOpen(false); setAssignTargetIds([]); setAssignAnchorRect(null); }}
        onApply={handleApplyAssignment}
        measurementNames={assignTargetNames}
        anchorRect={assignAnchorRect}
      />

      {/* New Measurement Modal */}
      <NewMeasurementModal
        isOpen={newModalOpen}
        onClose={() => setNewModalOpen(false)}
        onCreate={handleCreateMeasurement}
      />

      {/* Plan Import Modal */}
      <PlanImportModal
        isOpen={planImportOpen}
        onClose={() => setPlanImportOpen(false)}
        onComplete={handlePlanImportComplete}
        existingSheets={sheets}
      />

      {/* Scale Detect Modal */}
      {scaleDetectSheet && (
        <ScaleDetectModal
          isOpen={!!scaleDetectSheet}
          onClose={() => setScaleDetectSheet(null)}
          sheet={scaleDetectSheet}
          onScaleUpdate={handleScaleUpdate}
        />
      )}

      {/* Auto-Takeoff Modal */}
      <AutoTakeoffModal
        isOpen={autoTakeoffOpen && !regionSelectMode}
        onClose={() => { setAutoTakeoffOpen(false); setPendingRegionBounds(null); }}
        onRun={handleAutoTakeoffRun}
        sheets={sheets}
        activeSheetId={activeSheetId}
        onStartRegionSelect={() => {
          setAutoTakeoffOpen(false); // hide modal
          setRegionSelectMode(true); // activate canvas drawing
        }}
        externalRegionBounds={pendingRegionBounds}
      />

      {/* Auto-Takeoff running overlay */}
      {autoTakeoffRunning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="bg-white rounded-xl shadow-2xl p-8 flex flex-col items-center gap-4 max-w-xs">
            <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
              <div className="w-8 h-8 border-3 border-purple-600 border-t-transparent rounded-full animate-spin" />
            </div>
            <div className="text-center">
              <h3 className="text-sm font-semibold text-gray-900">Running Auto-Takeoff</h3>
              <p className="text-xs text-gray-500 mt-1">AI is analyzing the blueprint and detecting measurements...</p>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
              <div className="h-full bg-purple-600 rounded-full animate-pulse" style={{ width: '60%' }} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ===== Helpers for simulated AI markups ===== */
function randomPolygon(): number[][] {
  const cx = 200 + Math.random() * 400;
  const cy = 150 + Math.random() * 250;
  const r = 30 + Math.random() * 60;
  const sides = 4 + Math.floor(Math.random() * 3);
  return Array.from({ length: sides }, (_, i) => {
    const angle = (2 * Math.PI * i) / sides - Math.PI / 2;
    return [Math.round(cx + r * Math.cos(angle)), Math.round(cy + r * Math.sin(angle))];
  });
}

function randomLine(): number[][] {
  const x1 = 150 + Math.random() * 400;
  const y1 = 120 + Math.random() * 300;
  const segs = 2 + Math.floor(Math.random() * 3);
  const pts = [[Math.round(x1), Math.round(y1)]];
  for (let i = 1; i < segs; i++) {
    pts.push([Math.round(x1 + i * (40 + Math.random() * 60)), Math.round(y1 + (Math.random() - 0.5) * 80)]);
  }
  return pts;
}

function randomPoints(): number[][] {
  const count = 2 + Math.floor(Math.random() * 5);
  return Array.from({ length: count }, () => [
    Math.round(150 + Math.random() * 450),
    Math.round(120 + Math.random() * 300),
  ]);
}
